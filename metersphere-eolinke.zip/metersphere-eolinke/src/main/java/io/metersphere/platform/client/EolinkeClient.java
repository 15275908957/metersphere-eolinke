package io.metersphere.platform.client;

import io.metersphere.platform.api.BaseClient;

public abstract class EolinkeClient extends BaseClient {

}
