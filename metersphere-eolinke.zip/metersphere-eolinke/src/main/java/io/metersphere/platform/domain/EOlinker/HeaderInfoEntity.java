package io.metersphere.platform.domain.EOlinker;

import lombok.Data;

@Data
public class HeaderInfoEntity {
    private String headerName;
    private String headerValue;
}
