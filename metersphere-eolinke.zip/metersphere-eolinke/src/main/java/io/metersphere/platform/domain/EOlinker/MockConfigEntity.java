package io.metersphere.platform.domain.EOlinker;

import lombok.Data;

@Data
public class MockConfigEntity {
    private String rule;
    private String type;
}
