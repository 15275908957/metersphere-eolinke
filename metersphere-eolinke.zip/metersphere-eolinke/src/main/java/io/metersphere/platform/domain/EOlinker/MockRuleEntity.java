package io.metersphere.platform.domain.EOlinker;

import lombok.Data;

@Data
public class MockRuleEntity {
    private String paramKey;
    private String type;
    private String paramType;
    private Integer $index;
}
