package io.metersphere.platform.domain.EOlinker;

import lombok.Data;

@Data
public class ParamValueEntity {
    private String value;
    private String valueDescription;
}
