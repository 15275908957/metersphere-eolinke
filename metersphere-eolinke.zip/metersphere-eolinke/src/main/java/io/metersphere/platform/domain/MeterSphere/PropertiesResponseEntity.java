package io.metersphere.platform.domain.MeterSphere;

import lombok.Data;

@Data
public class PropertiesResponseEntity {
    private String type;
    private PropertiesResponseMockEntity mock;
}
