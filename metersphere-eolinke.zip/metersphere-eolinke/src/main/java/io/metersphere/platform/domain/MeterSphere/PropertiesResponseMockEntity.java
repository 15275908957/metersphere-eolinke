package io.metersphere.platform.domain.MeterSphere;

import lombok.Data;

@Data
public class PropertiesResponseMockEntity {
    private String mock;
}
