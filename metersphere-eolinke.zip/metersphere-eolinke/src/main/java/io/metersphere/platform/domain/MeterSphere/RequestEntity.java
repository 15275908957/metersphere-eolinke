package io.metersphere.platform.domain.MeterSphere;

import com.alibaba.fastjson2.JSONObject;
import org.apache.commons.text.StringEscapeUtils;

public class RequestEntity {
}
