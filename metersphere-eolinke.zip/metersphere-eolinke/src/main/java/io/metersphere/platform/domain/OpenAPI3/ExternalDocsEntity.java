package io.metersphere.platform.domain.OpenAPI3;

public class ExternalDocsEntity {
}
