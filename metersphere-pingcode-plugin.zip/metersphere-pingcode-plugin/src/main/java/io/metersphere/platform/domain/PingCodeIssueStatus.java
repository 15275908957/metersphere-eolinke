package io.metersphere.platform.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PingCodeIssueStatus {

    private String id;
    private String name;
    private String type;
}
