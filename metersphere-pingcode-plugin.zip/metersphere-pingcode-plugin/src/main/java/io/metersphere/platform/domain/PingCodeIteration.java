package io.metersphere.platform.domain;

import lombok.Data;

@Data
public class PingCodeIteration {
    private String id;
    private String url;
    private String name;
    private String status;

}
