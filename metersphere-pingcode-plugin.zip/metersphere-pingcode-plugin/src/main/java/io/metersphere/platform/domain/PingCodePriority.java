package io.metersphere.platform.domain;

import lombok.Data;

@Data
public class PingCodePriority {
    private String id;
    private String url;
    private String name;
    private String type;
}
