package io.metersphere.platform.impl;


import im.metersphere.plugin.exception.MSPluginException;
import im.metersphere.plugin.utils.JSON;
import im.metersphere.plugin.utils.LogUtil;
import io.metersphere.base.domain.IssuesWithBLOBs;
import io.metersphere.platform.api.AbstractPlatform;
import io.metersphere.platform.constants.CustomFieldType;
import io.metersphere.platform.domain.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class PingCodePlatform extends AbstractPlatform {
    protected PingCodeClient pingCodeClient;
    protected SimpleDateFormat sdfWithZone = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    protected SimpleDateFormat sdfWithOutZone = new SimpleDateFormat("yyyy-MM-dd");

    protected Boolean isSass = false;
    protected PingCodeProjectConfig projectConfig;

    public PingCodePlatform(PlatformRequest request) {
        super.key = PingCodePlatformMetaInfo.KEY;
        super.request = request;
        pingCodeClient = new PingCodeClient();
        setConfig();
    }

    public PingCodeConfig setConfig() {
        PingCodeConfig config = getIntegrationConfig();
        validateConfig(config);
        pingCodeClient.setConfig(config);
        return config;
    }

    private void validateConfig(PingCodeConfig config) {
        pingCodeClient.setConfig(config);
        if (config == null) {
            MSPluginException.throwException("PingCode config is null");
        }
    }

    public PingCodeConfig getIntegrationConfig() {
        return getIntegrationConfig(PingCodeConfig.class);
    }


    @Override
    public List<DemandDTO> getDemands(String projectConfigStr) {

        List<DemandDTO> list = new ArrayList<>();
        projectConfig = getProjectConfig(projectConfigStr);

        int maxResults = 50, startAt = 0;
        List demands;
        do {
            demands = pingCodeClient.getDemands(projectConfig.getPingCodeKey(), projectConfig.getPingCodeStoryTypeId(), startAt, maxResults);
            for (int i = 0; i < demands.size(); i++) {
                Map o = (Map) demands.get(i);
                LogUtil.info("提取对象为：" + JSON.toJSONString(o));
                String issueKey = o.get("id").toString();
                String title = o.get("title").toString();
                DemandDTO demandDTO = new DemandDTO();
                demandDTO.setName(title);
                demandDTO.setId(issueKey);
                demandDTO.setPlatform(key);
                list.add(demandDTO);
            }
            startAt += maxResults;
        } while (demands.size() >= maxResults);
        return list;
    }

    @Override
    public IssuesWithBLOBs addIssue(PlatformIssuesUpdateRequest request) {
        projectConfig = getProjectConfig(request.getProjectConfig());
        validateProjectKey(projectConfig.getPingCodeKey());

        Map addPingCodeIssueParam = buildUpdateParam(request, projectConfig.getPingCodeIssueTypeId(), projectConfig.getPingCodeKey());
        PingCodeAddIssueResponse result = pingCodeClient.addIssue(JSON.toJSONString(addPingCodeIssueParam));
        PingCodeIssue pingCodeIssue = pingCodeClient.getIssues(result.getId());

        LogUtil.info("获取到的缺陷内容：" + JSON.toJSONString(pingCodeIssue));

        request.setPlatformStatus("");
        request.setPlatformId(result.getId());
        request.setId(UUID.randomUUID().toString());
        return request;
    }

    @Override
    public void syncAllIssues(SyncAllIssuesRequest syncRequest) {
        PingCodeProjectConfig projectConfig = getProjectConfig(syncRequest.getProjectConfig());
        this.isThirdPartTemplate = projectConfig.isThirdPartTemplate();

        int startAt = 0;
        int maxResults = 100;
        List<PingCodeIssue> pingCodeIssues;
        int currentSize;

        this.defaultCustomFields = syncRequest.getDefaultCustomFields();
        this.projectConfig = projectConfig;

        do {
            SyncAllIssuesResult syncIssuesResult = new SyncAllIssuesResult();

            String pingCodeKey = projectConfig.getPingCodeKey();
            validateProjectKey(pingCodeKey);

            PingCodeIssueListResponse result = pingCodeClient.getProjectIssues(startAt, maxResults, pingCodeKey, "bug");
            pingCodeIssues = result.getValues();

            currentSize = pingCodeIssues.size();
            List<String> allIds = pingCodeIssues.stream().map(PingCodeIssue::getId).collect(Collectors.toList());

            syncIssuesResult.setAllIds(allIds);

            if (syncRequest != null) {
                pingCodeIssues = filterSyncJiraIssueByCreated(pingCodeIssues, syncRequest);
            }
            LogUtil.info("过滤后的缺陷信息为：" + JSON.toJSONString(pingCodeIssues));
            if (CollectionUtils.isNotEmpty(pingCodeIssues)) {
                for (PingCodeIssue pingCodeIssue : pingCodeIssues) {
                    PlatformIssuesDTO issue = getUpdateIssue(null, pingCodeIssue);
                    // 设置临时UUID，同步附件时需要用
                    issue.setId(UUID.randomUUID().toString());
                    issue.setPlatformId(pingCodeIssue.getId());
                    LogUtil.info("当前转化的缺陷为：" + JSON.toJSONString(issue));

                    syncIssuesResult.getUpdateIssues().add(issue);
                }
            }

            startAt += maxResults;
            HashMap<Object, Object> syncParam = buildSyncAllParam(syncIssuesResult);
            syncRequest.getHandleSyncFunc().accept(syncParam);
        } while (currentSize >= maxResults);
    }


    @Override
    public List<SelectOption> getProjectOptions(GetOptionRequest request) {
        String method = request.getOptionMethod();
        try {
            // 这里反射调用 getIssueTypes 获取下拉框选项
            return (List<SelectOption>) this.getClass().getMethod(method, request.getClass()).invoke(this, request);
        } catch (InvocationTargetException e) {
            LogUtil.error(e);
            MSPluginException.throwException(e.getTargetException());
        } catch (Exception e) {
            LogUtil.error(e);
            MSPluginException.throwException(e);
        }
        return null;
    }

    @Override
    public IssuesWithBLOBs updateIssue(PlatformIssuesUpdateRequest request) {
        projectConfig = getProjectConfig(request.getProjectConfig());
        validateProjectKey(projectConfig.getPingCodeKey());
        Map param = buildUpdateParam(request, projectConfig.getPingCodeIssueTypeId(), projectConfig.getPingCodeKey());
        pingCodeClient.updateIssue(request.getPlatformId(), JSON.toJSONString(param));
        return request;
    }

    @Override
    public void deleteIssue(String platformId) {
        pingCodeClient.deleteIssue(platformId);
    }

    @Override
    public void validateIntegrationConfig() {
        pingCodeClient.auth4AccessToken();
    }

    @Override
    public void validateProjectConfig(String projectConfig) {
        try {
            PingCodeProjectConfig projectConfigEntity = getProjectConfig(projectConfig);
            PingCodeProject project = pingCodeClient.getProject(projectConfigEntity.getPingCodeKey());
            if (project != null && StringUtils.isBlank(project.getId())) {
                MSPluginException.throwException("项目不存在");
            }
        } catch (Exception e) {
            LogUtil.error(e);
            MSPluginException.throwException(e.getMessage());
        }
    }

    @Override
    public void validateUserConfig(String userConfig) {

    }

    @Override
    public boolean isAttachmentUploadSupport() {
        return false;
    }


    @Override
    public SyncIssuesResult syncIssues(SyncIssuesRequest request) {
        LogUtil.info("同步缺陷请求为：" + JSON.toJSONString(request));

        projectConfig = getProjectConfig(request.getProjectConfig());
        super.isThirdPartTemplate = projectConfig.isThirdPartTemplate();

        if (projectConfig.isThirdPartTemplate()) {
            super.defaultCustomFields = getCustomFieldsValuesString(getThirdPartCustomField(request.getProjectConfig()));
        } else {
            super.defaultCustomFields = request.getDefaultCustomFields();
        }
        List<PlatformIssuesDTO> issues = request.getIssues();
        LogUtil.info("开始执行同步缺陷。。。。。。。。。");

        SyncIssuesResult syncIssuesResult = new SyncIssuesResult();

        issues.forEach(item -> {
            try {
                LogUtil.info("参数信息item为：" + JSON.toJSONString(item));
                PingCodeIssue pingCodeIssue = pingCodeClient.getIssues(item.getPlatformId());
                item = getUpdateIssue(item, pingCodeIssue);
                syncIssuesResult.getUpdateIssues().add(item);
                // 同步第三方平台附件
            } catch (HttpClientErrorException e) {
                if (e.getRawStatusCode() == 404) {
                    syncIssuesResult.getDeleteIssuesIds().add(item.getId());
                }
            } catch (Exception e) {
                LogUtil.error(e);
            }
        });
        LogUtil.info("结束执行同步缺陷。。。。。。。。。" + JSON.toJSONString(syncIssuesResult));
        return syncIssuesResult;
    }

    public PlatformIssuesDTO getUpdateIssue(PlatformIssuesDTO issue, PingCodeIssue pingCodeIssue) {
        try {
            if (issue == null) {
                issue = new PlatformIssuesDTO();
                if (StringUtils.isNotBlank(defaultCustomFields)) {
                    issue.setCustomFieldList(JSON.parseArray(defaultCustomFields, PlatformCustomFieldItemDTO.class));
                } else {
                    issue.setCustomFieldList(new ArrayList<>());
                }
            } else {
                mergeCustomField(issue, defaultCustomFields);
            }
            List<PlatformCustomFieldItemDTO> fields = new ArrayList<>();
            PlatformCustomFieldItemDTO customField3 = new PlatformCustomFieldItemDTO();
            customField3.setId("title");
            customField3.setCustomData("title");
            customField3.setName("标题");
            customField3.setRequired(true);
            customField3.setValue(pingCodeIssue.getTitle());
            customField3.setType(CustomFieldType.INPUT.getValue());
            fields.add(customField3);

            PlatformCustomFieldItemDTO customField4 = new PlatformCustomFieldItemDTO();
            customField4.setId("description");
            customField4.setCustomData("description");
            customField4.setName("缺陷内容");
            customField4.setRequired(true);
            customField4.setValue(pingCodeIssue.getDescription());
            customField4.setType(CustomFieldType.RICH_TEXT.getValue());
            fields.add(customField4);


            PlatformCustomFieldItemDTO customField6 = new PlatformCustomFieldItemDTO();
            customField6.setId("start_at");
            customField6.setCustomData("start_at");
            customField6.setName("开始时间");
            customField6.setRequired(false);
            customField6.setValue(pingCodeIssue.getStart_at());
            customField6.setType(CustomFieldType.DATE.getValue());
            fields.add( customField6);

            PlatformCustomFieldItemDTO customField5 = new PlatformCustomFieldItemDTO();
            customField5.setId("end_at");
            customField5.setCustomData("end_at");
            customField5.setName("截止时间");
            customField5.setRequired(false);
            customField5.setValue(pingCodeIssue.getEndAt());
            customField5.setType(CustomFieldType.DATE.getValue());
            fields.add(customField5);

            LogUtil.info("参数为：" + JSON.toJSONString(issue.getCustomFieldList()));
            issue.setTitle(pingCodeIssue.getTitle());
            issue.setLastmodify(null);
            issue.setDescription(pingCodeIssue.getDescription());
            issue.setPlatform(key);
            issue.setCustomFields(JSON.toJSONString(fields));
            return issue;
        } catch (Exception e) {
            LogUtil.error(e);
            MSPluginException.throwException(e);
            return null;
        }
    }

    @Override
    public List<PlatformCustomFieldItemDTO> getThirdPartCustomField(String projectConfigStr) {

        projectConfig = getProjectConfig(projectConfigStr);

        List<PlatformCustomFieldItemDTO> fields = new ArrayList<>();

        PlatformCustomFieldItemDTO customField3 = new PlatformCustomFieldItemDTO();
        customField3.setId("title");
        customField3.setCustomData("title");
        customField3.setName("标题");
        customField3.setRequired(true);
        customField3.setType(CustomFieldType.INPUT.getValue());
        fields.add(customField3);

        PlatformCustomFieldItemDTO customField4 = new PlatformCustomFieldItemDTO();
        customField4.setId("description");
        customField4.setCustomData("description");
        customField4.setName("缺陷内容");
        customField4.setRequired(true);
        customField4.setType(CustomFieldType.RICH_TEXT.getValue());
        fields.add(customField4);


        PlatformCustomFieldItemDTO customField6 = new PlatformCustomFieldItemDTO();
        customField6.setId("start_at");
        customField6.setCustomData("start_at");
        customField6.setName("开始时间");
        customField6.setRequired(false);
        customField6.setType(CustomFieldType.DATE.getValue());
        fields.add(customField6);

        PlatformCustomFieldItemDTO customField5 = new PlatformCustomFieldItemDTO();
        customField5.setId("end_at");
        customField5.setCustomData("end_at");
        customField5.setName("截止时间");
        customField5.setRequired(false);
        customField5.setType(CustomFieldType.DATE.getValue());
        fields.add(customField5);

        PlatformCustomFieldItemDTO customField2 = new PlatformCustomFieldItemDTO();
        customField2.setId("biaoji");
        customField2.setCustomData("biaoji");
        customField2.setName("标记");
        customField2.setRequired(false);
        customField2.setType(CustomFieldType.INPUT.getValue());
        fields.add(customField2);

        fields = fields.stream().filter(i -> StringUtils.isNotBlank(i.getType()))
                .collect(Collectors.toList());

        // 按类型排序，富文本排最后，input 排最前面，title 排第一个
        fields.sort((a, b) -> {
            if (a.getType().equals(CustomFieldType.RICH_TEXT.getValue())) return 1;
            if (b.getType().equals(CustomFieldType.RICH_TEXT.getValue())) return -1;
            if (a.getId().equals("title")) return -1;
            if (b.getId().equals("title")) return 1;
            if (a.getType().equals(CustomFieldType.INPUT.getValue())) return -1;
            if (b.getType().equals(CustomFieldType.INPUT.getValue())) return 1;
            return a.getType().compareTo(b.getType());
        });
        return fields;
    }


    @Override
    public ResponseEntity proxyForGet(String url, Class responseEntityClazz) {
        return null;
    }

    @Override
    public void syncIssuesAttachment(SyncIssuesAttachmentRequest request) {

    }

    @Override
    public List<PlatformStatusDTO> getStatusList(String issueKey) {
        List<PlatformStatusDTO> platformStatusDTOS = new ArrayList<>();
        List statusList = pingCodeClient.getIssueStatusList();
        if (CollectionUtils.isNotEmpty(statusList)) {
            statusList.forEach(item -> {
                Map o = (Map) item;
                PlatformStatusDTO platformStatusDTO = new PlatformStatusDTO();
                platformStatusDTO.setLabel(o.get("name").toString());
                platformStatusDTO.setValue(o.get("id").toString());
                platformStatusDTOS.add(platformStatusDTO);
            });
        }
        return platformStatusDTOS;
    }

    public PingCodeProjectConfig getProjectConfig(String configStr) {
        if (StringUtils.isBlank(configStr)) {
            MSPluginException.throwException("请在项目中添加项目配置！");
        }
        PingCodeProjectConfig projectConfig = JSON.parseObject(configStr, PingCodeProjectConfig.class);
        return projectConfig;
    }

    /**
     * 由 getProjectOptions 反射调用
     *
     * @return
     */
    public List<SelectOption> getIssueTypes(GetOptionRequest request) {
        List<SelectOption> selectOptions = new ArrayList<>();
        selectOptions.add(new SelectOption("epic", "epic"));
        selectOptions.add(new SelectOption("feature", "feature"));
        selectOptions.add(new SelectOption("story", "story"));
        selectOptions.add(new SelectOption("task", "task"));
        selectOptions.add(new SelectOption("bug", "bug"));
        selectOptions.add(new SelectOption("issue", "issue"));
        LogUtil.info("返回内容为：" + JSON.toJSONString(selectOptions));
        return selectOptions;
    }

    private Map<String, Object> buildUpdateParam(PlatformIssuesUpdateRequest request, String issueTypeId, String pingCodeKey) {
        request.setPlatform(key);
        LogUtil.info("请求内容为：" + JSON.toJSONString(request));

        Map addPingCodeIssueParam = new LinkedHashMap();
        if (isThirdPartTemplate) {
            parseCustomFiled(request, addPingCodeIssueParam);
            request.setTitle(addPingCodeIssueParam.get("title").toString());
        } else {
            addPingCodeIssueParam.put("project_id", pingCodeKey);
            addPingCodeIssueParam.put("title", request.getTitle());
            addPingCodeIssueParam.put("description", request.getDescription());
            parseCustomFiled(request, addPingCodeIssueParam);
        }

        return addPingCodeIssueParam;
    }


    private void parseCustomFiled(PlatformIssuesUpdateRequest request, Map fields) {
        List<PlatformCustomFieldItemDTO> customFields = request.getCustomFieldList();
        customFields.forEach(item -> {
            String fieldName = item.getCustomData();
            String name = item.getName();
            if (StringUtils.isNotBlank(fieldName)) {
                if (ObjectUtils.isNotEmpty(item.getValue())) {
                    if (StringUtils.isNotBlank(item.getType())) {
                        if (StringUtils.equalsAny(item.getType(), "select", "radio", "member")) {
                            Map param = new LinkedHashMap<>();
                            if (fieldName.equals("assignee") || fieldName.equals("reporter")) {
                                if (isThirdPartTemplate || isSass) {
                                    param.put("id", item.getValue());
                                } else {
                                    param.put("accountId", item.getValue());
                                }
                            } else {
                                param.put("id", item.getValue());
                            }
                            fields.put(fieldName, param);
                        } else if (StringUtils.equalsAny(item.getType(), "multipleSelect", "checkbox", "multipleMember")) {
                            List attrs = new ArrayList();
                            if (item.getValue() != null) {
                                List values = JSON.parseArray((String) item.getValue());
                                values.forEach(v -> {
                                    Map param = new LinkedHashMap<>();
                                    param.put("id", v);
                                    attrs.add(param);
                                });
                            }
                            fields.put(fieldName, attrs);
                        } else if (StringUtils.equalsAny(item.getType(), "cascadingSelect")) {
                            if (item.getValue() != null) {
                                Map attr = new LinkedHashMap<>();
                                List values = JSON.parseArray((String) item.getValue());
                                if (CollectionUtils.isNotEmpty(values)) {
                                    if (values.size() > 0) {
                                        attr.put("id", values.get(0));
                                    }
                                    if (values.size() > 1) {
                                        Map param = new LinkedHashMap<>();
                                        param.put("id", values.get(1));
                                        attr.put("child", param);
                                    }
                                } else {
                                    attr.put("id", item.getValue());
                                }
                                fields.put(fieldName, attr);
                            }
                        } else if (StringUtils.equalsAny(item.getType(), "richText")) {
                            fields.put(fieldName, item.getValue().toString());
                            if (fieldName.equals("description")) {
                                request.setDescription(item.getValue().toString());
                            }
                        } else if (StringUtils.equalsAny(item.getType(), "date", "datetime")) {
                            try {
                                if (StringUtils.equals(item.getCustomData(), "start_at") && StringUtils.isNotEmpty(item.getValue().toString())) {
                                    fields.put(fieldName, sdfWithOutZone.parse(item.getValue().toString()).getTime() / 1000);
                                }
                                if (StringUtils.equals(item.getCustomData(), "end_at") && StringUtils.isNotEmpty(item.getValue().toString())) {
                                    fields.put(fieldName, sdfWithOutZone.parse(item.getValue().toString()).getTime() / 1000);
                                }
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                        } else {
                            fields.put(fieldName, item.getValue());
                        }
                    }

                }
            }
        });
    }

    private List<PingCodeIssue> filterSyncJiraIssueByCreated(List<PingCodeIssue> pingCodeIssues, SyncAllIssuesRequest syncRequest) {
        LogUtil.info("同步请求内容为：" + syncRequest.getCreateTime().longValue() + "  syncRequest:" + syncRequest.isPre());
        List<PingCodeIssue> filterIssues = pingCodeIssues.stream().filter(pingCodeIssue -> {
            long createTimeMills = 0;
            createTimeMills = pingCodeIssue.getCreated_at().longValue() * 1000;
            if (syncRequest.isPre()) {
                return createTimeMills <= syncRequest.getCreateTime().longValue();
            } else {
                return createTimeMills >= syncRequest.getCreateTime().longValue();
            }
        }).collect(Collectors.toList());
        return filterIssues;
    }
}
