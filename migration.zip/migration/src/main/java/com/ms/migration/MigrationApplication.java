package com.ms.migration;

import com.ms.migration.swing.MeterSphereImportApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import javax.swing.*;

/**
 * @author liujianqiang
 */
@SpringBootApplication
public class MigrationApplication {

	public static void main(String[] args) {
		System.setProperty("java.awt.headless", "false");

		ConfigurableApplicationContext context = SpringApplication.run(MigrationApplication.class, args);
		MeterSphereImportApplication swingApplication = context.getBean(MeterSphereImportApplication.class);

		SwingUtilities.invokeLater(() -> {
			swingApplication.initUI();
		});
	}

}
