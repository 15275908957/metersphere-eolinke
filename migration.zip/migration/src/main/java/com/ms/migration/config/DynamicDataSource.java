package com.ms.migration.config;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * @author liujianqiang
 * @Classname DynamicDataSource
 * @Description TODO
 * @Date 2023/9/5 下午2:52
 * @Created by liujianqiang
 */
public class DynamicDataSource extends AbstractRoutingDataSource {

    @Override
    protected Object determineCurrentLookupKey() {
        return DynamicDataSourceContextHolder.getContextKey();
    }
}
