//package com.ms.migration.config;
//
//import org.mybatis.spring.annotation.MapperScan;
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.transaction.annotation.EnableTransactionManagement;
//
//
///**
// * @author liujianqiang
// * @Classname MybatisConfig
// * @Description TODO
// * @Date 2023/8/4 上午10:38
// * @Created by liujianqiang
// */
//@Configuration    //该注解类似于spring配置文件
//@MapperScan(basePackages = "com.ms.migration.mapper", sqlSessionFactoryRef = "sqlSessionFactory")
//@EnableTransactionManagement
//public class MybatisConfig {
//
//}