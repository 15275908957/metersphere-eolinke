package com.ms.migration.constants;

/**
 * @author liujianqiang
 * @Classname AdminConstants
 * @Description TODO
 * @Date 2023/8/7 上午11:24
 * @Created by liujianqiang
 */
public interface AdminConstants {
    public static final String USER_NAME = "admin";
    public static final String PASS_WORD = "admin@123";
    public static final Integer TIME_OUT = 3600;
    public static final String LOGIN_USER_NAME = "loginUserName";
    public static final String LOGIN_URL = "/login";
    public static final String INDEX_URL = "/index";
    public static final String PROFILE_URL = "/profile";
    public static final String LOGOUT_URL = "/logout";
    public static final String PROTOCOL_HTTP = "HTTP";

    public static final String HTTP_CONFIG_MODULE = "MODULE";
    public static final String TRASH_STATUS = "Trash";
    public static final String FULL_COVERAGE = "fullCoverage";



}
