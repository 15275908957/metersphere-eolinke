package com.ms.migration.constants;

/**
 * @author liujianqiang
 * @Classname DataSourceConstants
 * @Description TODO
 * @Date 2023/9/5 下午2:47
 * @Created by liujianqiang
 */
public interface DataSourceConstants {
    public static String DS_KEY_MASTER = "master";
    public static String DS_KEY_SLAVE = "slave";
}
