package com.ms.migration.controller;

import com.ms.migration.constants.AdminConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;




/**
 * @author liujianqiang
 */
@Controller
@RequestMapping
public class IndexController {


    @GetMapping({"", "/", AdminConstants.INDEX_URL, "/index.html"})
    public String index(HttpServletRequest request) {
        request.setAttribute("path", "index");
        return AdminConstants.INDEX_URL;
    }
    @GetMapping({AdminConstants.LOGIN_URL})
    public String login() {
        return AdminConstants.LOGIN_URL;
    }

    @PostMapping(value = AdminConstants.LOGIN_URL)
    public String login(@RequestParam("userName") String userName,
                        @RequestParam("password") String password,
                        HttpSession session) {

        if (StringUtils.isEmpty(userName) || StringUtils.isEmpty(password)) {
            session.setAttribute("errorMsg", "用户名或密码不能为空");
            return AdminConstants.LOGIN_URL;
        }

        if (!StringUtils.equals(userName, AdminConstants.USER_NAME) || !StringUtils.equals(password, AdminConstants.PASS_WORD) ) {
            session.setAttribute("errorMsg", "用户名或密码错误");
            return AdminConstants.LOGIN_URL;
        }
        session.setAttribute("loginUserName", AdminConstants.USER_NAME);
        session.setMaxInactiveInterval(AdminConstants.TIME_OUT);
        return "redirect:" + AdminConstants.INDEX_URL;

    }

    @GetMapping(AdminConstants.PROFILE_URL)
    public String profile(HttpServletRequest request) {
        String loginUserName = (String) request.getSession().getAttribute("loginUserName");
        if (!StringUtils.equals(loginUserName,AdminConstants.USER_NAME)) {
            return AdminConstants.LOGIN_URL;
        }
        request.setAttribute("path", "profile");
        request.setAttribute("loginUserName", AdminConstants.USER_NAME);
        return AdminConstants.PROFILE_URL;
    }
    @GetMapping(AdminConstants.LOGOUT_URL)
    public String logout(HttpServletRequest request) {
        request.getSession().removeAttribute("loginUserName");
        request.getSession().removeAttribute("errorMsg");
        return AdminConstants.LOGIN_URL;
    }
}
