package com.ms.migration.controller;

import com.ms.migration.domain.Workspace;
import com.ms.migration.entity.ConfigEntity;
import com.ms.migration.service.MigrationService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author liujianqiang
 */
@RestController
@RequestMapping("project-resource")
public class MigrationController {

    @Resource
    private MigrationService migrationService;
    /**
     * 获取源配置信息
     */
    @GetMapping(value = "/source")
    public ConfigEntity getSourceConfig(){
        ConfigEntity configEntity = new ConfigEntity();


        return null;
    }

    /**
     * 获取目标配置信息
     */
    @GetMapping(value = "/target")
    public ConfigEntity getTargetConfig(){

        return null;
    }

    /**
     * 获取源空间配置信息
     */
    @GetMapping(value = "/workspace")
    public List<Workspace> getWorkspaceList(){
        return migrationService.getWorkspaces();
    }
}
