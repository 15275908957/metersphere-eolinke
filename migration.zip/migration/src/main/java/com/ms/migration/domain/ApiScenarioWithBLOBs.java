package com.ms.migration.domain;

import java.io.Serializable;

public class ApiScenarioWithBLOBs extends ApiScenario implements Serializable {
    private String scenarioDefinition;

    private String description;

    private String environmentJson;

    private static final long serialVersionUID = 1L;

    public String getScenarioDefinition() {
        return scenarioDefinition;
    }

    public void setScenarioDefinition(String scenarioDefinition) {
        this.scenarioDefinition = scenarioDefinition == null ? null : scenarioDefinition.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public String getEnvironmentJson() {
        return environmentJson;
    }

    public void setEnvironmentJson(String environmentJson) {
        this.environmentJson = environmentJson == null ? null : environmentJson.trim();
    }
}