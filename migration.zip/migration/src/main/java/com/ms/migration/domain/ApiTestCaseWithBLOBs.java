package com.ms.migration.domain;

import java.io.Serializable;

public class ApiTestCaseWithBLOBs extends ApiTestCase implements Serializable {
    private String description;

    private String request;

    private static final long serialVersionUID = 1L;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request == null ? null : request.trim();
    }
}