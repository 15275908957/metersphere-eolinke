package com.ms.migration.domain;

import java.io.Serializable;

public class ApiTestEnvironmentWithBLOBs extends ApiTestEnvironment implements Serializable {
    private String variables;

    private String headers;

    private String config;

    private String hosts;

    private static final long serialVersionUID = 1L;

    public String getVariables() {
        return variables;
    }

    public void setVariables(String variables) {
        this.variables = variables == null ? null : variables.trim();
    }

    public String getHeaders() {
        return headers;
    }

    public void setHeaders(String headers) {
        this.headers = headers == null ? null : headers.trim();
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config == null ? null : config.trim();
    }

    public String getHosts() {
        return hosts;
    }

    public void setHosts(String hosts) {
        this.hosts = hosts == null ? null : hosts.trim();
    }
}