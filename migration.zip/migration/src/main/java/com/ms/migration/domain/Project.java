package com.ms.migration.domain;

import java.io.Serializable;

public class Project implements Serializable {
    private String id;

    private String workspaceId;

    private String name;

    private String description;

    private Long createTime;

    private Long updateTime;

    private String tapdId;

    private String jiraKey;

    private String zentaoId;

    private String azureDevopsId;

    private String caseTemplateId;

    private String issueTemplateId;

    private String createUser;

    private String systemId;

    private String azureFilterId;

    private String platform;

    private Boolean thirdPartTemplate;

    private Boolean versionEnable;

    private String apiTemplateId;

    private String issueConfig;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getWorkspaceId() {
        return workspaceId;
    }

    public void setWorkspaceId(String workspaceId) {
        this.workspaceId = workspaceId == null ? null : workspaceId.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public String getTapdId() {
        return tapdId;
    }

    public void setTapdId(String tapdId) {
        this.tapdId = tapdId == null ? null : tapdId.trim();
    }

    public String getJiraKey() {
        return jiraKey;
    }

    public void setJiraKey(String jiraKey) {
        this.jiraKey = jiraKey == null ? null : jiraKey.trim();
    }

    public String getZentaoId() {
        return zentaoId;
    }

    public void setZentaoId(String zentaoId) {
        this.zentaoId = zentaoId == null ? null : zentaoId.trim();
    }

    public String getAzureDevopsId() {
        return azureDevopsId;
    }

    public void setAzureDevopsId(String azureDevopsId) {
        this.azureDevopsId = azureDevopsId == null ? null : azureDevopsId.trim();
    }

    public String getCaseTemplateId() {
        return caseTemplateId;
    }

    public void setCaseTemplateId(String caseTemplateId) {
        this.caseTemplateId = caseTemplateId == null ? null : caseTemplateId.trim();
    }

    public String getIssueTemplateId() {
        return issueTemplateId;
    }

    public void setIssueTemplateId(String issueTemplateId) {
        this.issueTemplateId = issueTemplateId == null ? null : issueTemplateId.trim();
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId == null ? null : systemId.trim();
    }

    public String getAzureFilterId() {
        return azureFilterId;
    }

    public void setAzureFilterId(String azureFilterId) {
        this.azureFilterId = azureFilterId == null ? null : azureFilterId.trim();
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform == null ? null : platform.trim();
    }

    public Boolean getThirdPartTemplate() {
        return thirdPartTemplate;
    }

    public void setThirdPartTemplate(Boolean thirdPartTemplate) {
        this.thirdPartTemplate = thirdPartTemplate;
    }

    public Boolean getVersionEnable() {
        return versionEnable;
    }

    public void setVersionEnable(Boolean versionEnable) {
        this.versionEnable = versionEnable;
    }

    public String getApiTemplateId() {
        return apiTemplateId;
    }

    public void setApiTemplateId(String apiTemplateId) {
        this.apiTemplateId = apiTemplateId == null ? null : apiTemplateId.trim();
    }

    public String getIssueConfig() {
        return issueConfig;
    }

    public void setIssueConfig(String issueConfig) {
        this.issueConfig = issueConfig == null ? null : issueConfig.trim();
    }
}