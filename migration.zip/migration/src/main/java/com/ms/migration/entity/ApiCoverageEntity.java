package com.ms.migration.entity;

import com.ms.migration.domain.ApiDefinitionWithBLOBs;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author liujianqiang
 * @Classname ApiCoverageEntity
 * @Description TODO
 * @Date 2023/9/1 下午5:54
 * @Created by liujianqiang
 */
public class ApiCoverageEntity {
    private List<ApiDefinitionWithBLOBs> createDefinitions;
    private List<String> createIds;
    private ConcurrentHashMap<String, String> repeatApiDefinitions;

    public List<ApiDefinitionWithBLOBs> getCreateDefinitions() {
        return createDefinitions;
    }

    public void setCreateDefinitions(List<ApiDefinitionWithBLOBs> createDefinitions) {
        this.createDefinitions = createDefinitions;
    }

    public ConcurrentHashMap<String, String> getRepeatApiDefinitions() {
        return repeatApiDefinitions;
    }

    public void setRepeatApiDefinitions(ConcurrentHashMap<String, String> repeatApiDefinitions) {
        this.repeatApiDefinitions = repeatApiDefinitions;
    }

    public List<String> getCreateIds() {
        return createIds;
    }

    public void setCreateIds(List<String> createIds) {
        this.createIds = createIds;
    }
}
