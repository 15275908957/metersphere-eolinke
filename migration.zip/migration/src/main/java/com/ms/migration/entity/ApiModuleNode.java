package com.ms.migration.entity;

import com.ms.migration.domain.ApiModule;

import java.util.List;

/**
 * @author liujianqiang
 * @Classname ApiModuleNode
 * @Description TODO
 * @Date 2023/8/8 下午5:01
 * @Created by liujianqiang
 */
public class ApiModuleNode extends ApiModule {
    private List<ApiModuleNode> children;

    public List<ApiModuleNode> getChildren() {
        return children;
    }

    public void setChildren(List<ApiModuleNode> children) {
        this.children = children;
    }

}
