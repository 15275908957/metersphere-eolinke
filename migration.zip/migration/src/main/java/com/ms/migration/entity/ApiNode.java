package com.ms.migration.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * @Classname ApiNode
 * @Description TODO
 * @Date 2023/8/31 上午11:16
 * @Created by liujianqiang
 */
public class ApiNode {

    private String id;
    private String type;
    private List<ApiNode> childrenNode = new ArrayList<>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<ApiNode> getChildrenNode() {
        return childrenNode;
    }

    public void setChildrenNode(List<ApiNode> childrenNode) {
        this.childrenNode = childrenNode;
    }
}
