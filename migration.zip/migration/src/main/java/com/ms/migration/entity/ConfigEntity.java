package com.ms.migration.entity;

import java.io.Serializable;

/**
 * @author liujianqiang
 * @Classname ConfigEntity
 * @Description TODO
 * @Date 2023/8/4 下午5:21
 * @Created by liujianqiang
 */
public class ConfigEntity implements Serializable {
    private String workspaceName;
    private String workspaceId;
    private String projectId;
    private String projectName;

    public String getWorkspaceName() {
        return workspaceName;
    }

    public void setWorkspaceName(String workspaceName) {
        this.workspaceName = workspaceName;
    }

    public String getWorkspaceId() {
        return workspaceId;
    }

    public void setWorkspaceId(String workspaceId) {
        this.workspaceId = workspaceId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
}
