package com.ms.migration.entity;

import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.ParseException;
/**
 * @Classname HeaderEntity
 * @Description TODO
 * @Date 2023/8/3 下午5:47
 * @Created by liujianqiang
 */


public class HeaderEntity implements Header {
    private String name;

    private String value;

    public HeaderEntity(String name, String value) {
        this.name = name;
        this.value = value;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getValue() {
        return this.value;
    }

    @Override
    public HeaderElement[] getElements() throws ParseException {
        return new HeaderElement[0];
    }
}
