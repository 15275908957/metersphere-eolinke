package com.ms.migration.entity;

import com.ms.migration.domain.ApiScenarioModule;

import java.util.List;

/**
 * @author liujianqiang
 * @Classname ModuleTreeNode
 * @Description TODO
 * @Date 2023/8/9 下午3:12
 * @Created by liujianqiang
 */
public class ScenarioModuleNode extends ApiScenarioModule {
    private List<ScenarioModuleNode> children;

    public List<ScenarioModuleNode> getChildren() {
        return children;
    }

    public void setChildren(List<ScenarioModuleNode> children) {
        this.children = children;
    }
}
