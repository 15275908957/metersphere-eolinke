package com.ms.migration.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liujianqiang
 * @Classname ScenarioNode
 * @Description TODO
 * @Date 2023/8/25 下午5:45
 * @Created by liujianqiang
 */
public class ScenarioNode {
    private String id;
    private List<ScenarioNode> childrenNode = new ArrayList<>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<ScenarioNode> getChildrenNode() {
        return childrenNode;
    }

    public void setChildrenNode(List<ScenarioNode> childrenNode) {
        this.childrenNode = childrenNode;
    }
}
