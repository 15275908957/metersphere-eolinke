package com.ms.migration.mapper;

import com.ms.migration.domain.ProjectVersion;
import com.ms.migration.domain.ProjectVersionExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
@Mapper
public interface ProjectVersionMapper {
    long countByExample(ProjectVersionExample example);

    int deleteByExample(ProjectVersionExample example);

    int deleteByPrimaryKey(String id);

    int insert(ProjectVersion record);

    int insertSelective(ProjectVersion record);

    List<ProjectVersion> selectByExample(ProjectVersionExample example);

    ProjectVersion selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") ProjectVersion record, @Param("example") ProjectVersionExample example);

    int updateByExample(@Param("record") ProjectVersion record, @Param("example") ProjectVersionExample example);

    int updateByPrimaryKeySelective(ProjectVersion record);

    int updateByPrimaryKey(ProjectVersion record);
}