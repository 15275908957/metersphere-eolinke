package com.ms.migration.salvemapper;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.ApiDefinition;
import com.ms.migration.domain.ApiDefinitionExample;
import com.ms.migration.domain.ApiDefinitionWithBLOBs;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
@Mapper

public interface SalveApiDefinitionMapper {
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    long countByExample(ApiDefinitionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByExample(ApiDefinitionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insert(ApiDefinitionWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insertSelective(ApiDefinitionWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiDefinitionWithBLOBs> selectByExampleWithBLOBs(ApiDefinitionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiDefinition> selectByExample(ApiDefinitionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    ApiDefinitionWithBLOBs selectByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleSelective(@Param("record") ApiDefinitionWithBLOBs record, @Param("example") ApiDefinitionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleWithBLOBs(@Param("record") ApiDefinitionWithBLOBs record, @Param("example") ApiDefinitionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExample(@Param("record") ApiDefinition record, @Param("example") ApiDefinitionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeySelective(ApiDefinitionWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeyWithBLOBs(ApiDefinitionWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKey(ApiDefinition record);
}