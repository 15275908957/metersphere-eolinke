package com.ms.migration.salvemapper;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.ApiModule;
import com.ms.migration.domain.ApiModuleExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
@Mapper
public interface SalveApiModuleMapper {
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    long countByExample(ApiModuleExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByExample(ApiModuleExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insert(ApiModule record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insertSelective(ApiModule record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiModule> selectByExample(ApiModuleExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    ApiModule selectByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleSelective(@Param("record") ApiModule record, @Param("example") ApiModuleExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExample(@Param("record") ApiModule record, @Param("example") ApiModuleExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeySelective(ApiModule record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKey(ApiModule record);
}