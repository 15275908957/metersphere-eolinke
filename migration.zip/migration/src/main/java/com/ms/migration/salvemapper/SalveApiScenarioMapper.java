package com.ms.migration.salvemapper;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.ApiScenario;
import com.ms.migration.domain.ApiScenarioExample;
import com.ms.migration.domain.ApiScenarioWithBLOBs;
import java.util.List;
import org.apache.ibatis.annotations.Param;
@DS(DataSourceConstants.DS_KEY_SLAVE)
public interface SalveApiScenarioMapper {
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    long countByExample(ApiScenarioExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByExample(ApiScenarioExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insert(ApiScenarioWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insertSelective(ApiScenarioWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiScenarioWithBLOBs> selectByExampleWithBLOBs(ApiScenarioExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiScenario> selectByExample(ApiScenarioExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    ApiScenarioWithBLOBs selectByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleSelective(@Param("record") ApiScenarioWithBLOBs record, @Param("example") ApiScenarioExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleWithBLOBs(@Param("record") ApiScenarioWithBLOBs record, @Param("example") ApiScenarioExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExample(@Param("record") ApiScenario record, @Param("example") ApiScenarioExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeySelective(ApiScenarioWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeyWithBLOBs(ApiScenarioWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKey(ApiScenario record);
}