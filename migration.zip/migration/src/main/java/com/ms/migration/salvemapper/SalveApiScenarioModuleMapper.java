package com.ms.migration.salvemapper;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.ApiScenarioModule;
import com.ms.migration.domain.ApiScenarioModuleExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
@Mapper
@DS(DataSourceConstants.DS_KEY_SLAVE)
public interface SalveApiScenarioModuleMapper {
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    long countByExample(ApiScenarioModuleExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByExample(ApiScenarioModuleExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insert(ApiScenarioModule record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insertSelective(ApiScenarioModule record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiScenarioModule> selectByExample(ApiScenarioModuleExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    ApiScenarioModule selectByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleSelective(@Param("record") ApiScenarioModule record, @Param("example") ApiScenarioModuleExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExample(@Param("record") ApiScenarioModule record, @Param("example") ApiScenarioModuleExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeySelective(ApiScenarioModule record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKey(ApiScenarioModule record);
}