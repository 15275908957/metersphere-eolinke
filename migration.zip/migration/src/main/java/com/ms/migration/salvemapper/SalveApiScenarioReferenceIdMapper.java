package com.ms.migration.salvemapper;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.ApiScenarioReferenceId;
import com.ms.migration.domain.ApiScenarioReferenceIdExample;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
@Mapper
@DS(DataSourceConstants.DS_KEY_SLAVE)
public interface SalveApiScenarioReferenceIdMapper {
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    long countByExample(ApiScenarioReferenceIdExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByExample(ApiScenarioReferenceIdExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insert(ApiScenarioReferenceId record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insertSelective(ApiScenarioReferenceId record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiScenarioReferenceId> selectByExample(ApiScenarioReferenceIdExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    ApiScenarioReferenceId selectByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleSelective(@Param("record") ApiScenarioReferenceId record, @Param("example") ApiScenarioReferenceIdExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExample(@Param("record") ApiScenarioReferenceId record, @Param("example") ApiScenarioReferenceIdExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeySelective(ApiScenarioReferenceId record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKey(ApiScenarioReferenceId record);
}