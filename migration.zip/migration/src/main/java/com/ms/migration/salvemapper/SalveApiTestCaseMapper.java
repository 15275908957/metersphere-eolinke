package com.ms.migration.salvemapper;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.ApiTestCase;
import com.ms.migration.domain.ApiTestCaseExample;
import com.ms.migration.domain.ApiTestCaseWithBLOBs;
import java.util.List;
import org.apache.ibatis.annotations.Param;
@DS(DataSourceConstants.DS_KEY_SLAVE)
public interface SalveApiTestCaseMapper {
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    long countByExample(ApiTestCaseExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByExample(ApiTestCaseExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insert(ApiTestCaseWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insertSelective(ApiTestCaseWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiTestCaseWithBLOBs> selectByExampleWithBLOBs(ApiTestCaseExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiTestCase> selectByExample(ApiTestCaseExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    ApiTestCaseWithBLOBs selectByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleSelective(@Param("record") ApiTestCaseWithBLOBs record, @Param("example") ApiTestCaseExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleWithBLOBs(@Param("record") ApiTestCaseWithBLOBs record, @Param("example") ApiTestCaseExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExample(@Param("record") ApiTestCase record, @Param("example") ApiTestCaseExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeySelective(ApiTestCaseWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeyWithBLOBs(ApiTestCaseWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKey(ApiTestCase record);
}