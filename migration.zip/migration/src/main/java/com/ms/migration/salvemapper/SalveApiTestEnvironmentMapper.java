package com.ms.migration.salvemapper;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.ApiTestEnvironment;
import com.ms.migration.domain.ApiTestEnvironmentExample;
import com.ms.migration.domain.ApiTestEnvironmentWithBLOBs;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
@Mapper
@DS(DataSourceConstants.DS_KEY_SLAVE)
public interface SalveApiTestEnvironmentMapper {
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    long countByExample(ApiTestEnvironmentExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByExample(ApiTestEnvironmentExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insert(ApiTestEnvironmentWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insertSelective(ApiTestEnvironmentWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiTestEnvironmentWithBLOBs> selectByExampleWithBLOBs(ApiTestEnvironmentExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ApiTestEnvironment> selectByExample(ApiTestEnvironmentExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    ApiTestEnvironmentWithBLOBs selectByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleSelective(@Param("record") ApiTestEnvironmentWithBLOBs record, @Param("example") ApiTestEnvironmentExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleWithBLOBs(@Param("record") ApiTestEnvironmentWithBLOBs record, @Param("example") ApiTestEnvironmentExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExample(@Param("record") ApiTestEnvironment record, @Param("example") ApiTestEnvironmentExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeySelective(ApiTestEnvironmentWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeyWithBLOBs(ApiTestEnvironmentWithBLOBs record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKey(ApiTestEnvironment record);
}