package com.ms.migration.salvemapper;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Optional;

/**
 * @author liujianqiang
 * @Classname MigrationMapper
 * @Description TODO
 * @Date 2023/8/17 下午3:14
 * @Created by liujianqiang
 */
@Mapper
@DS(DataSourceConstants.DS_KEY_SLAVE)
public interface SalveMigrationMapper {
    /**
     * 获取项目中apiModulePath的最大值
     * @param projectId
     * @return Integer
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    Integer getMaxLevel(@Param("projectId") String projectId);

    /**
     * 获取项目中父子级相关的模块路径ID集合
     * @param moduleId
     * @return List<String>
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<String> getModuleIdsByModuleId(@Param("moduleId") String moduleId);

    /**
     * 获取项目中scenarioModulePath的最大值
     * @param projectId
     * @return Integer
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    Integer getScenarioMaxLevel(@Param("projectId") String projectId);
    /**
     * 获取项目中排序接口定义的排序
     * @param projectId
     * @param baseOrder
     * @return Long
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    Long getDefinitionLastOrder(@Param("projectId") String projectId, @Param("baseOrder") Long baseOrder);

    /**
     * 获取项目中排序接口定义的排序
     * @param projectId
     * @param baseOrder
     * @return Long
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    Long getCaseLastOrder(@Param("projectId") String projectId, @Param("baseOrder") Long baseOrder);

    /**
     * 获取项目中排序场景的排序
     * @param projectId
     * @param baseOrder
     * @return Long
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    Long getScenarioLastOrder(@Param("projectId") String projectId, @Param("baseOrder") Long baseOrder);


    /**
     * 获取num
     * @param projectId
     * @return Integer
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    Integer getScenarioNextNum(@Param("projectId") String projectId);

    /**
     * 获取num
     * @param definitionId
     * @return Integer
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    Integer getCaseNextNum(@Param("definitionId") String definitionId);
    /**
     * 获取num
     * @param projectId
     * @return Integer
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    Integer getDefinitionNextNum(@Param("projectId") String projectId);

    /**
     * 获取接口定义当前num
     * @param id
     * @return Integer
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    Integer getDefinitionConcurrentNum(@Param("id") String id);


}
