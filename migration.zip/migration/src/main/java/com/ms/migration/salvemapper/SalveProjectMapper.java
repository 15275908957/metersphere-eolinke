package com.ms.migration.salvemapper;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.Project;
import com.ms.migration.domain.ProjectExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
@Mapper
@DS(DataSourceConstants.DS_KEY_SLAVE)
public interface SalveProjectMapper {
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    long countByExample(ProjectExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByExample(ProjectExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insert(Project record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insertSelective(Project record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<Project> selectByExampleWithBLOBs(ProjectExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<Project> selectByExample(ProjectExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    Project selectByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleSelective(@Param("record") Project record, @Param("example") ProjectExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleWithBLOBs(@Param("record") Project record, @Param("example") ProjectExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExample(@Param("record") Project record, @Param("example") ProjectExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeySelective(Project record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeyWithBLOBs(Project record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKey(Project record);
}