package com.ms.migration.salvemapper;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.ProjectVersion;
import com.ms.migration.domain.ProjectVersionExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
@Mapper
@DS(DataSourceConstants.DS_KEY_SLAVE)
public interface SalveProjectVersionMapper {
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    long countByExample(ProjectVersionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByExample(ProjectVersionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int deleteByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insert(ProjectVersion record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int insertSelective(ProjectVersion record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    List<ProjectVersion> selectByExample(ProjectVersionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    ProjectVersion selectByPrimaryKey(String id);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExampleSelective(@Param("record") ProjectVersion record, @Param("example") ProjectVersionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByExample(@Param("record") ProjectVersion record, @Param("example") ProjectVersionExample example);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKeySelective(ProjectVersion record);
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    int updateByPrimaryKey(ProjectVersion record);
}