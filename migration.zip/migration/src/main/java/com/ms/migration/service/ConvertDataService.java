package com.ms.migration.service;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.ms.migration.constants.AdminConstants;
import com.ms.migration.constants.ElementConstants;
import com.ms.migration.constants.MsHashTreeConstants;
import com.ms.migration.domain.*;
import com.ms.migration.entity.ApiCoverageEntity;
import com.ms.migration.entity.ApiNode;
import com.ms.migration.entity.ScenarioNode;
import com.ms.migration.mapper.*;
import com.ms.migration.salvemapper.*;
import com.ms.migration.swing.MeterSphereImportApplication;
import com.ms.migration.tools.ServiceUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.*;


/**
 * @author liujianqiang
 * @Classname ConvertEnvService
 * @Description TODO
 * @Date 2023/8/15 下午5:58
 * @Created by liujianqiang
 */
@Service
public class ConvertDataService {

    @Resource
    private ApiTestEnvironmentMapper apiTestEnvironmentMapper;

    @Resource
    private ApiModuleMapper apiModuleMapper;

    @Resource
    private MigrationMapper migrationMapper;

    @Resource
    private ApiDefinitionMapper apiDefinitionMapper;

    @Resource
    private ProjectVersionMapper projectVersionMapper;

    @Resource
    private ApiTestCaseMapper apiTestCaseMapper;

    @Resource
    private ApiScenarioModuleMapper apiScenarioModuleMapper;

    @Resource
    private ApiScenarioMapper apiScenarioMapper;



    @Resource
    private SalveApiTestEnvironmentMapper salveapiTestEnvironmentMapper;

    @Resource
    private SalveApiModuleMapper salveapiModuleMapper;

    @Resource
    private SalveMigrationMapper salvemigrationMapper;

    @Resource
    private SalveApiDefinitionMapper salveapiDefinitionMapper;

    @Resource
    private SalveProjectVersionMapper salveprojectVersionMapper;

    @Resource
    private SalveApiTestCaseMapper salveapiTestCaseMapper;

    @Resource
    private SalveApiScenarioModuleMapper salveapiScenarioModuleMapper;

    @Resource
    private SalveApiScenarioMapper salveapiScenarioMapper;

    @Resource
    private GoalMigrationService goalMigrationService;

    @Resource
    private SalveApiScenarioReferenceIdMapper salveApiScenarioReferenceIdMapper;


    private static ConcurrentHashMap<String,String> ENVIRONMENT = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String,String> API_MODULE = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String,String> API_DEFINITION_MAP = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String,String> API_CASE_MAP = new ConcurrentHashMap<>();

    private static Long DEFINITION_ORDER;
    private static int DEFINITION_NUM;
    private static Long CASE_ORDER;
    private static Long SCENARIO_ORDER;
    private static int SCENARIO_NUM;

    private static ConcurrentHashMap<String,String> PROJECT_VERSION = new ConcurrentHashMap<>();

    private static ConcurrentHashMap<String,String> API_SCENARIO_MODULE = new ConcurrentHashMap<>();

//    private static CopyOnWriteArrayList<String> SCENARIO_MODULE_PARENTS = new CopyOnWriteArrayList<>();


    private static ConcurrentHashMap<String,String> API_SCENARIO_MAP =  new ConcurrentHashMap<>();
   // private static Set<String> SCENARIO_NODE = new TreeSet<>();


    /**
     * clear缓存数据为一下次执行
     * */
    public void clearStaticData(){
        ENVIRONMENT.clear();
        API_MODULE.clear();
        API_DEFINITION_MAP.clear();
        API_CASE_MAP.clear();
        PROJECT_VERSION.clear();
        API_SCENARIO_MODULE.clear();
        API_SCENARIO_MAP.clear();
    }

    /**
     * clear缓存数据为一下次执行
     * */
    public void initOrderAndNum(String goalProjectId){
        DEFINITION_ORDER = goalMigrationService.getImportDefinitionNextOrder(goalProjectId);
        CASE_ORDER = goalMigrationService.getImportCaseNextOrder(goalProjectId);
        SCENARIO_ORDER = goalMigrationService.getImportScenarioNextOrder(goalProjectId);
        DEFINITION_NUM = goalMigrationService.getDefinitionNextNum(goalProjectId);
        SCENARIO_NUM = goalMigrationService.getScenarioNextNum(goalProjectId);

    }
    /**
     * 转换接口定义指定路径及下属路径的所有数据
     * */
    public void convertApiAndCaseByModuleId(String apiModuleId, String projectId,String goalProjectId){

        Set<String> moduleIds = new TreeSet<>();
        moduleIds.add(apiModuleId);
        this.ObtainChildrenNodeId(apiModuleId, projectId,moduleIds);
        moduleIds.forEach(item-> {
            convertApi(item,projectId,goalProjectId);
        });
        convertCase(projectId,goalProjectId);
    }
    /**
     * 递归所有当前节点的子节点ID
     * */
    public void ObtainChildrenNodeId(String apiModuleId,String projectId,Set<String> ids){
        ApiModuleExample example = new ApiModuleExample();

        if(MeterSphereImportApplication.IMPORT_TYPE){
            example.createCriteria().andProjectIdEqualTo(projectId).andProtocolEqualTo(AdminConstants.PROTOCOL_HTTP);
            List<ApiModule> childrenNodeId = apiModuleMapper.selectByExample(example);
            ids.addAll(childrenNodeId.stream().map(ApiModule :: getId).collect(Collectors.toList()));
            return;
        }
        example.clear();
        example.createCriteria().andParentIdEqualTo(apiModuleId);
        List<ApiModule> childrenNodeId = apiModuleMapper.selectByExample(example);
        childrenNodeId.forEach( item ->{

            ids.add(item.getId());

            this.ObtainChildrenNodeId(item.getId(),projectId,ids);

        });
    }

    /**
     * API_转换
     * */
    public void convertApi(String apiModuleId, String projectId,String goalProjectId){

        ApiCoverageEntity apiCoverageEntity = this.removeDefinitionRepeat(apiModuleId,projectId,goalProjectId);

        List<ApiDefinitionWithBLOBs> createDefinitions = apiCoverageEntity.getCreateDefinitions();
        List<String> createIds = apiCoverageEntity.getCreateIds();
        ConcurrentHashMap<String, String> repeatApiDefinitions = apiCoverageEntity.getRepeatApiDefinitions();

        for(int i = 0; i< createDefinitions.size(); i++){
            ApiDefinitionWithBLOBs apiDefinitionWithBLOBs =  createDefinitions.get(i);
            String definitionId = apiDefinitionWithBLOBs.getId();
            ApiTestCaseExample apiTestCaseExample = new ApiTestCaseExample();
            if(CollectionUtils.isNotEmpty(createIds) && createIds.contains(apiDefinitionWithBLOBs.getId())){
                this.convertRelationApi(apiDefinitionWithBLOBs,goalProjectId);
            }else{
                String goalDefinition = repeatApiDefinitions.get(apiDefinitionWithBLOBs.getId());
                API_DEFINITION_MAP.put(apiDefinitionWithBLOBs.getId(),goalDefinition);
            }
            this.createCaseByApi(apiTestCaseExample,definitionId,goalProjectId);
        }
    }
    public void createCaseByApi(ApiTestCaseExample apiTestCaseExample, String apiDefinitionId,String goalProjectId) {
        apiTestCaseExample.clear();
        apiTestCaseExample.createCriteria().andApiDefinitionIdEqualTo(apiDefinitionId)
                .andStatusNotEqualTo(AdminConstants.TRASH_STATUS);

        List<ApiTestCaseWithBLOBs> apiTestCases = apiTestCaseMapper.selectByExampleWithBLOBs(apiTestCaseExample);

        for(int k = 0; k< apiTestCases.size(); k++){

            ApiTestCaseWithBLOBs testCaseWithBLOBs =  apiTestCases.get(k);

            this.convertRelationCase(testCaseWithBLOBs,goalProjectId);
        }
    }
    /**
     * 去除目标项目中重复的数据
     * 去重 如果url可重复 则模块+名称+请求方式+路径 唯一，否则 请求方式+路径唯一，
     * 覆盖模式留重复的最后一个，不覆盖留第一个
     * 接口首次导入逻辑：
     * 接口导入时，系统没有重复文件：
     * 按照当前系统里是否是同一接口的逻辑判断--->导入的文件里是否有重复接口
     *
     * 将ID,num全部置于null,覆盖的时候会增加ID，用以区分更新还是新增，处理导入文件里的重复的case，如果覆盖，则取重复的最后一个，否则取第一个
     * 用集合收集其他重复的Case用于在检验是第一次导入时作为相关接口的case导入进来
     * */
    private ApiCoverageEntity removeDefinitionRepeat(String apiModuleId, String projectId, String goalProjectId) {

        ApiCoverageEntity apiCoverageEntity = new ApiCoverageEntity();
        ApiDefinitionExample apiDefinitionExample = new ApiDefinitionExample();

        apiDefinitionExample.createCriteria().andModuleIdEqualTo(apiModuleId).andProjectIdEqualTo(projectId)
                .andStatusNotEqualTo(AdminConstants.TRASH_STATUS).andModulePathIsNotNull();

        List<ApiDefinitionWithBLOBs> apiDefinitions = apiDefinitionMapper.selectByExampleWithBLOBs(apiDefinitionExample);

        List<String> createIds = new ArrayList<>();

        ConcurrentHashMap<String,String> repeatApiDefinitions = new ConcurrentHashMap<>();

        if(CollectionUtils.isNotEmpty(apiDefinitions)){

            ListIterator<ApiDefinitionWithBLOBs> iterator = apiDefinitions.listIterator();

            while (iterator.hasNext()){

                ApiDefinitionWithBLOBs item = iterator.next();

                apiDefinitionExample.clear();
                ApiDefinitionExample.Criteria criteria = apiDefinitionExample.createCriteria();
                criteria.andModuleIdEqualTo(API_MODULE.get(apiModuleId))
                        .andProjectIdEqualTo(goalProjectId)
                        .andStatusNotEqualTo(AdminConstants.TRASH_STATUS)
                        .andNameEqualTo(item.getName())
                        .andMethodEqualTo(item.getMethod())
                        .andPathEqualTo(item.getPath())
                        .andVersionIdEqualTo(PROJECT_VERSION.get(item.getVersionId()));
                if(StringUtils.isNotBlank(item.getModulePath())){
                    criteria.andModulePathEqualTo(item.getModulePath());
                }

                List<ApiDefinitionWithBLOBs> apiDefinitions2 = salveapiDefinitionMapper.selectByExampleWithBLOBs(apiDefinitionExample);

                if(CollectionUtils.isEmpty(apiDefinitions2)){
                    createIds.add(item.getId());
                }else{
                    repeatApiDefinitions.put(item.getId(),apiDefinitions2.get(0).getId());
                }
            }
        }
        apiCoverageEntity.setCreateIds(createIds);
        apiCoverageEntity.setCreateDefinitions(apiDefinitions);
        apiCoverageEntity.setRepeatApiDefinitions(repeatApiDefinitions);
        return apiCoverageEntity;

    }



    /**
     * 如果场景涉及case
     * 创建或加载对应的API并检测case在目标项目是否已存在
     * */
    private void caseRepeat(ApiTestCaseWithBLOBs apiTestCaseWithBLOBs, String goalProjectId) {

        ApiDefinitionWithBLOBs apiDefinitionWithBLOBs = apiDefinitionMapper.selectByPrimaryKey(apiTestCaseWithBLOBs.getApiDefinitionId());

        String definitionId = apiDefinitionWithBLOBs.getId();

        if(apiDefinitionWithBLOBs != null) {

            ApiDefinitionExample example = new ApiDefinitionExample();
            example.clear();

            ApiDefinitionExample.Criteria criteria = example.createCriteria();
            criteria.andModuleIdEqualTo(API_MODULE.get(apiDefinitionWithBLOBs.getModuleId()))
                    .andProjectIdEqualTo(goalProjectId)
                    .andStatusNotEqualTo(AdminConstants.TRASH_STATUS)
                    .andNameEqualTo(apiDefinitionWithBLOBs.getName())
                    .andMethodEqualTo(apiDefinitionWithBLOBs.getMethod())
                    .andPathEqualTo(apiDefinitionWithBLOBs.getPath())
                    .andVersionIdEqualTo(PROJECT_VERSION.get(apiDefinitionWithBLOBs.getVersionId()));

            if(StringUtils.isNotBlank(apiDefinitionWithBLOBs.getModulePath())){
                criteria.andModulePathEqualTo(apiDefinitionWithBLOBs.getModulePath());
            }

            List<ApiDefinitionWithBLOBs> apiDefinitions2 = salveapiDefinitionMapper.selectByExampleWithBLOBs(example);

            if (CollectionUtils.isEmpty(apiDefinitions2)) {
                this.convertRelationApi(apiDefinitionWithBLOBs, goalProjectId);
            } else {
                API_DEFINITION_MAP.put(apiDefinitionWithBLOBs.getId(), apiDefinitions2.get(0).getId());
            }

            ApiTestCaseExample apiTestCaseExample = new ApiTestCaseExample();
            this.createCaseByApi(apiTestCaseExample,definitionId,goalProjectId);
        }

    }
    /**
     * 如果场景涉及API
     * 创建或加载对应的API并检测case在目标项目是否已存在,及联创建
     * */
    private void apiRepeat(ApiDefinitionWithBLOBs apiDefinitions, String goalProjectId) {

        if(apiDefinitions != null){

            ApiDefinitionExample example = new ApiDefinitionExample();
            example.clear();

            ApiDefinitionExample.Criteria criteria = example.createCriteria();
            criteria.andModuleIdEqualTo(API_MODULE.get(apiDefinitions.getModuleId()))
                    .andProjectIdEqualTo(goalProjectId)
                    .andStatusNotEqualTo(AdminConstants.TRASH_STATUS)
                    .andNameEqualTo(apiDefinitions.getName())
                    .andMethodEqualTo(apiDefinitions.getMethod())
                    .andPathEqualTo(apiDefinitions.getPath());
                    if(StringUtils.isNotBlank(apiDefinitions.getModulePath())){
                        criteria.andModulePathEqualTo(apiDefinitions.getModulePath());
                    }

            List<ApiDefinitionWithBLOBs> apiDefinitions2 = salveapiDefinitionMapper.selectByExampleWithBLOBs(example);

            if(CollectionUtils.isEmpty(apiDefinitions2)){
                this.convertRelationApi(apiDefinitions,goalProjectId);
            }else{
                API_DEFINITION_MAP.put(apiDefinitions.getId(),apiDefinitions2.get(0).getId());
            }
        }
    }


    private void convertRelationApi(ApiDefinitionWithBLOBs apiDefinitionWithBLOBs,String goalProjectId){

        String definitionIdA = apiDefinitionWithBLOBs.getId();

        String definitionIdB = UUID.randomUUID().toString();

        apiDefinitionWithBLOBs.setProjectId(goalProjectId);
        apiDefinitionWithBLOBs.setId(definitionIdB);
        apiDefinitionWithBLOBs.setRefId(definitionIdB);
        apiDefinitionWithBLOBs.setCreateTime(System.currentTimeMillis());
        apiDefinitionWithBLOBs.setUpdateTime(System.currentTimeMillis());
        if(apiDefinitionWithBLOBs.getOrder() != null){
            apiDefinitionWithBLOBs.setOrder( apiDefinitionWithBLOBs.getOrder() + DEFINITION_ORDER);
        }
        if(apiDefinitionWithBLOBs.getNum() != null){
            apiDefinitionWithBLOBs.setNum(apiDefinitionWithBLOBs.getNum() + DEFINITION_NUM);
        }
        apiDefinitionWithBLOBs.setVersionId(PROJECT_VERSION.get(apiDefinitionWithBLOBs.getVersionId()));
        apiDefinitionWithBLOBs.setModuleId(API_MODULE.get(apiDefinitionWithBLOBs.getModuleId()));

        JSONObject request = JSONObject.parseObject(apiDefinitionWithBLOBs.getRequest());

        request.put("id",definitionIdB);
        request.put("projectId",goalProjectId);

        apiDefinitionWithBLOBs.setRequest(JSONObject.toJSONString(request));

        salveapiDefinitionMapper.insertSelective(apiDefinitionWithBLOBs);

        API_DEFINITION_MAP.put(definitionIdA,definitionIdB);

    }

    /**
     * CASE_转换
     * */
    public void convertCase(String projectId,String goalProjectId){

        List<String> apiIds =  Collections.list(API_DEFINITION_MAP.keys());


       if( CollectionUtils.isNotEmpty(apiIds)){
           apiIds.forEach( apiId ->{
               ApiTestCaseExample apiTestCaseExample = new ApiTestCaseExample();
               apiTestCaseExample.createCriteria().andApiDefinitionIdEqualTo(apiId).andProjectIdEqualTo(projectId).andStatusNotEqualTo(AdminConstants.TRASH_STATUS);

               List<ApiTestCaseWithBLOBs> apiTestCases = apiTestCaseMapper.selectByExampleWithBLOBs(apiTestCaseExample);
               if(CollectionUtils.isNotEmpty(apiTestCases)){
//                   int caseCount = apiTestCases.size();

                   for(int i = 0; i< apiTestCases.size(); i++){

                       ApiTestCaseWithBLOBs testCaseWithBLOBs =  apiTestCases.get(i);

                       this.convertRelationCase(testCaseWithBLOBs,goalProjectId);

                   }
               }
           });
       }

    }


    private void convertRelationCase(ApiTestCaseWithBLOBs testCaseWithBLOBs,String goalProjectId){

        if(StringUtils.isBlank(API_DEFINITION_MAP.get(testCaseWithBLOBs.getApiDefinitionId()))){

            ApiDefinitionWithBLOBs apiDefinitionWithBLOBs = apiDefinitionMapper.selectByPrimaryKey(testCaseWithBLOBs.getApiDefinitionId());
            this.convertRelationApi(apiDefinitionWithBLOBs,goalProjectId);
        }

        ApiTestCaseExample apiTestCaseExample = new ApiTestCaseExample();

        apiTestCaseExample.clear();
        apiTestCaseExample.createCriteria()
                .andApiDefinitionIdEqualTo(API_DEFINITION_MAP.get(testCaseWithBLOBs.getApiDefinitionId()))
                .andProjectIdEqualTo(goalProjectId)
                .andStatusNotEqualTo(AdminConstants.TRASH_STATUS)
                .andNameEqualTo(testCaseWithBLOBs.getName())
                .andVersionIdEqualTo(PROJECT_VERSION.get(testCaseWithBLOBs.getVersionId()));

        List<ApiTestCaseWithBLOBs> goalApiTestCases = salveapiTestCaseMapper.selectByExampleWithBLOBs(apiTestCaseExample);


        if(CollectionUtils.isNotEmpty(goalApiTestCases)){
            API_CASE_MAP.put(testCaseWithBLOBs.getId(),goalApiTestCases.get(0).getId());
        }else{

            if(StringUtils.isNotBlank(API_CASE_MAP.get(testCaseWithBLOBs.getId()))){
                return;
            }

            String caseIdA = testCaseWithBLOBs.getId();

            String caseIdB = UUID.randomUUID().toString();

            testCaseWithBLOBs.setProjectId(goalProjectId);
            testCaseWithBLOBs.setId(caseIdB);
            testCaseWithBLOBs.setLastResultId(null);
            testCaseWithBLOBs.setCreateTime(System.currentTimeMillis());
            testCaseWithBLOBs.setUpdateTime(System.currentTimeMillis());
            if(testCaseWithBLOBs.getOrder() != null){
                testCaseWithBLOBs.setOrder( testCaseWithBLOBs.getOrder() + CASE_ORDER);
            }
            testCaseWithBLOBs.setNum(goalMigrationService.getCaseNextNum(API_DEFINITION_MAP.get(testCaseWithBLOBs.getApiDefinitionId())));

            testCaseWithBLOBs.setVersionId(PROJECT_VERSION.get(testCaseWithBLOBs.getVersionId()));
            testCaseWithBLOBs.setApiDefinitionId(API_DEFINITION_MAP.get(testCaseWithBLOBs.getApiDefinitionId()));

            JSONObject request = JSONObject.parseObject(testCaseWithBLOBs.getRequest());

            String useEnvironment = request.getString("useEnvironment");
            request.put("id",caseIdB);
            request.put("projectId",goalProjectId);
            if(StringUtils.isNotBlank(useEnvironment)){
                request.put("useEnvironment",ENVIRONMENT.get(useEnvironment));
            }

            testCaseWithBLOBs.setRequest(JSONObject.toJSONString(request));

            salveapiTestCaseMapper.insertSelective(testCaseWithBLOBs);

            API_CASE_MAP.put(caseIdA,caseIdB);
        }
    }

    /**
     * 版本转换
     * */
    public void convertVersion(String projectId,String goalProjectId){

        ProjectVersionExample exampleA = new ProjectVersionExample();
        exampleA.createCriteria().andProjectIdEqualTo(projectId);
        List<ProjectVersion> versionA = projectVersionMapper.selectByExample(exampleA);

        exampleA.clear();
        exampleA.createCriteria().andProjectIdEqualTo(goalProjectId);
        List<ProjectVersion> versionB = salveprojectVersionMapper.selectByExample(exampleA);

        ConcurrentMap<String,String> map = versionB.stream().collect(toConcurrentMap(ProjectVersion :: getName,ProjectVersion :: getId));

        versionA.forEach(itemA ->{

            String nameA = itemA.getName();

            if(map.keySet().contains(nameA)){
                PROJECT_VERSION.put(itemA.getId(),map.get(nameA));
            }else{
                ProjectVersion version = new ProjectVersion();
                BeanUtils.copyProperties(itemA,version);
                version.setId(UUID.randomUUID().toString());
                version.setProjectId(goalProjectId);
                salveprojectVersionMapper.insert(version);
                PROJECT_VERSION.put(itemA.getId(),version.getId());
            }
        });
    }

    /**
     * 比对模块路径
     * */
    public void compareCreateApiModulePath(String projectId,String goalProjectId){


        Integer maxLengthA = migrationMapper.getMaxLevel(projectId);
        //Integer maxLengthB = migrationMapper.getMaxLevel(goalProjectId);

        for(int i = 1; i <= maxLengthA.intValue() ; i++){

            ApiModuleExample apiModuleExampleA = new ApiModuleExample();
            apiModuleExampleA.clear();

            apiModuleExampleA.createCriteria().andProjectIdEqualTo(projectId)
                    .andProtocolEqualTo(AdminConstants.PROTOCOL_HTTP).andLevelEqualTo(i);

            List<ApiModule> apiModuleA = apiModuleMapper.selectByExample(apiModuleExampleA);

            apiModuleA.forEach( a ->{

                String aName = a.getName();
                String aId = a.getId();
                Integer aLevel = a.getLevel();
                String aParentId = a.getParentId();

                ApiModuleExample apiModuleExampleB = new ApiModuleExample();
                apiModuleExampleB.clear();

                apiModuleExampleB.createCriteria().andProjectIdEqualTo(goalProjectId)
                        .andProtocolEqualTo(AdminConstants.PROTOCOL_HTTP)
                        .andNameEqualTo(aName)
                        .andLevelEqualTo(aLevel);

                List<ApiModule> apiModuleB = salveapiModuleMapper.selectByExample(apiModuleExampleB);

                if(CollectionUtils.isNotEmpty(apiModuleB)){

                    String bId = apiModuleB.get(0).getId();
                    API_MODULE.put(aId,bId);

                }else{

                    ApiModule apiModuleC = new ApiModule();
                    ServiceUtils.copyProperties(a,apiModuleC);
                    apiModuleC.setId(UUID.randomUUID().toString());
                    apiModuleC.setProjectId(goalProjectId);

                    if(StringUtils.isNotBlank(aParentId) && !StringUtils.equals(aParentId,"0") ) {
                        apiModuleC.setParentId(API_MODULE.get(aParentId));
                    }
                    salveapiModuleMapper.insertSelective(apiModuleC);

                    API_MODULE.put(aId,apiModuleC.getId());
                }
            });

        }
    }

    /**
     * 比对场景模块路径
     * */
    public void convertScenarioModulePath(String projectId ,String goalProjectId){


        Integer maxLength = migrationMapper.getScenarioMaxLevel(projectId);

//        Collections.reverse(SCENARIO_MODULE_PARENTS);


        for(int i = 1; i <= maxLength; i++){

            ApiScenarioModuleExample apiScenarioModuleExample = new ApiScenarioModuleExample();
            apiScenarioModuleExample.clear();
            apiScenarioModuleExample.createCriteria().andProjectIdEqualTo(projectId).andLevelEqualTo(i);

            List<ApiScenarioModule> apiScenarioModules =  apiScenarioModuleMapper.selectByExample(apiScenarioModuleExample);


            apiScenarioModules.forEach(apiScenarioModuleA ->{
                String aName = apiScenarioModuleA.getName();
                String aId = apiScenarioModuleA.getId();
                Integer aLevel = apiScenarioModuleA.getLevel();
                String aParentId = apiScenarioModuleA.getParentId();

                ApiScenarioModuleExample apiModuleExampleB = new ApiScenarioModuleExample();
                apiModuleExampleB.clear();

                apiModuleExampleB.createCriteria().andProjectIdEqualTo(goalProjectId)
                        .andNameEqualTo(aName)
                        .andLevelEqualTo(aLevel);

                List<ApiScenarioModule> apiScenarioModuleB = salveapiScenarioModuleMapper.selectByExample(apiModuleExampleB);

                if(CollectionUtils.isNotEmpty(apiScenarioModuleB)){

                    String bId = apiScenarioModuleB.get(0).getId();
                    API_SCENARIO_MODULE.put(aId,bId);

                }else{

                    ApiScenarioModule apiScenarioModuleC = new ApiScenarioModule();
                    ServiceUtils.copyProperties(apiScenarioModuleA,apiScenarioModuleC);
                    apiScenarioModuleC.setId(UUID.randomUUID().toString());
                    apiScenarioModuleC.setProjectId(goalProjectId);
                    if(StringUtils.isNotBlank(aParentId) && !StringUtils.equals(aParentId,"0") ) {
                        apiScenarioModuleC.setParentId(API_SCENARIO_MODULE.get(aParentId));
                    }
                    salveapiScenarioModuleMapper.insertSelective(apiScenarioModuleC);

                    API_SCENARIO_MODULE.put(aId,apiScenarioModuleC.getId());
                }
            });
        }
    }


//    /**
//     * 递归获取场景moduleID
//     * */
//    public void convertScenarioModuleId(String scenarioModuleId){
//
//        ApiScenarioModule apiScenarioModuleA = apiScenarioModuleMapper.selectByPrimaryKey(scenarioModuleId);
//
//        if( StringUtils.isNotBlank(apiScenarioModuleA.getParentId()) ){
//            SCENARIO_MODULE_PARENTS.add(scenarioModuleId);
//            this.convertScenarioModuleId(apiScenarioModuleA.getParentId());
//        }
//    }
    private String getMethodFromSample(JSONObject item) {
        String method = null;
        if (item.containsKey(ElementConstants.TYPE) && item.containsKey(MsHashTreeConstants.METHOD)
                && StringUtils.equalsIgnoreCase(item.getString(ElementConstants.TYPE), ElementConstants.HTTP_SAMPLER)) {
            method = item.getString(MsHashTreeConstants.METHOD);
        }
        return method;
    }

    public List<ApiScenarioReferenceId> deepElementRelation(String scenarioId, JSONArray hashTree) {
        List<ApiScenarioReferenceId> deepRelations = new LinkedList<>();
        if (hashTree != null) {
            for (int index = 0; index < hashTree.size(); index++) {
                JSONObject item = hashTree.getJSONObject(index);
                if (item.containsKey(ElementConstants.ID) && item.containsKey(MsHashTreeConstants.REFERENCED)) {
                    String method = null;
                    String url = null;
                    if (item.containsKey(MsHashTreeConstants.PATH) && StringUtils.isNotEmpty(MsHashTreeConstants.PATH)) {
                        url = item.getString(MsHashTreeConstants.PATH);
                    } else if (item.containsKey(MsHashTreeConstants.URL)) {
                        url = item.getString(MsHashTreeConstants.URL);
                    }
                    if (item.containsKey(MsHashTreeConstants.METHOD)) {
                        method = item.getString(MsHashTreeConstants.METHOD);
                    }
                    ApiScenarioReferenceId saveItem = new ApiScenarioReferenceId();
                    saveItem.setId(UUID.randomUUID().toString());
                    saveItem.setApiScenarioId(scenarioId);
                    saveItem.setReferenceId(item.getString(MsHashTreeConstants.ID));
                    saveItem.setReferenceType(item.getString(MsHashTreeConstants.REFERENCED));
                    saveItem.setDataType(item.getString(MsHashTreeConstants.REF_TYPE));
                    saveItem.setCreateTime(System.currentTimeMillis());
                    saveItem.setCreateUserId(MsHashTreeConstants.ADMIN);
                    saveItem.setMethod(method);
                    saveItem.setUrl(url);
                    deepRelations.add(saveItem);
                }
                if (item.containsKey(MsHashTreeConstants.HASH_TREE)) {
                    deepRelations.addAll(this.deepElementRelation(scenarioId, item.getJSONArray(MsHashTreeConstants.HASH_TREE)));
                }
            }
        }
        return deepRelations;
    }
    public void insertApiScenarioReferenceIds(List<ApiScenarioReferenceId> list) {
        if (CollectionUtils.isNotEmpty(list)) {
            for (ApiScenarioReferenceId apiScenarioReferenceId : list) {
                salveApiScenarioReferenceIdMapper.insert(apiScenarioReferenceId);
            }

        }
    }
    public void deleteByScenarioId(String scenarioId) {
        ApiScenarioReferenceIdExample example = new ApiScenarioReferenceIdExample();
        example.createCriteria().andApiScenarioIdEqualTo(scenarioId);
        salveApiScenarioReferenceIdMapper.deleteByExample(example);
    }
    /**
     * 转换引用关系
     * */
    public void convertScenarioReference(String goalProjectId){
        ApiScenarioExample example = new ApiScenarioExample();
        example.clear();
        example.createCriteria().andProjectIdEqualTo(goalProjectId);
        List<ApiScenarioWithBLOBs> apiScenarioWithBLOBs = salveapiScenarioMapper.selectByExampleWithBLOBs(example);

        apiScenarioWithBLOBs.forEach(scenario ->{
            if (scenario.getId() == null) {
                return;
            }
            this.deleteByScenarioId(scenario.getId());
            List<ApiScenarioReferenceId> savedList = this.getApiAndScenarioRelation(scenario);
            this.insertApiScenarioReferenceIds(savedList);
        });

    }
    public List<ApiScenarioReferenceId> getApiAndScenarioRelation(ApiScenarioWithBLOBs scenario) {
        List<ApiScenarioReferenceId> returnList = new ArrayList<>();
        if (StringUtils.isNotEmpty(scenario.getScenarioDefinition())) {
            JSONObject jsonObject = JSONObject.parseObject(scenario.getScenarioDefinition());
            if (!jsonObject.containsKey(ElementConstants.HASH_TREE)) {
                return returnList;
            }
            JSONArray containsKeyhTree = jsonObject.getJSONArray(ElementConstants.HASH_TREE);
            for (int index = 0; index < containsKeyhTree.size(); index++) {
                JSONObject item = containsKeyhTree.getJSONObject(index);
                if (item == null || StringUtils.equals(item.getString(MsHashTreeConstants.TYPE), ElementConstants.SCENARIO)) {
                    ApiScenarioReferenceId saveItem = new ApiScenarioReferenceId();
                    saveItem.setId(UUID.randomUUID().toString());
                    saveItem.setApiScenarioId(scenario.getId());
                    saveItem.setReferenceId(item.getString(ElementConstants.ID));
                    saveItem.setReferenceType(item.getString(MsHashTreeConstants.REFERENCED));
                    saveItem.setDataType(item.getString(ElementConstants.REF_TYPE));
                    saveItem.setCreateTime(System.currentTimeMillis());
                    saveItem.setCreateUserId(MsHashTreeConstants.ADMIN);
                    returnList.add(saveItem);
                    continue;
                }

                if (item.containsKey(ElementConstants.ID) && item.containsKey(MsHashTreeConstants.REFERENCED)) {
                    String url = null;
                    String method;
                    if (item.containsKey(MsHashTreeConstants.PATH) && StringUtils.isNotEmpty(MsHashTreeConstants.PATH)) {
                        url = item.getString(MsHashTreeConstants.PATH);
                    } else if (item.containsKey(MsHashTreeConstants.URL)) {
                        url = item.getString(MsHashTreeConstants.URL);
                    }
                    method = this.getMethodFromSample(item);
                    ApiScenarioReferenceId saveItem = new ApiScenarioReferenceId();
                    saveItem.setId(UUID.randomUUID().toString());
                    saveItem.setApiScenarioId(scenario.getId());
                    saveItem.setReferenceId(item.getString(ElementConstants.ID));
                    saveItem.setReferenceType(item.getString(MsHashTreeConstants.REFERENCED));
                    saveItem.setDataType(item.getString(ElementConstants.REF_TYPE));
                    saveItem.setCreateTime(System.currentTimeMillis());
                    saveItem.setCreateUserId(MsHashTreeConstants.ADMIN);
                    saveItem.setUrl(url);
                    saveItem.setMethod(method);
                    returnList.add(saveItem);
                }
                if (item.containsKey(ElementConstants.HASH_TREE)) {
                    returnList.addAll(this.deepElementRelation(scenario.getId(), item.getJSONArray(ElementConstants.HASH_TREE)));
                }
            }
        }
        if (CollectionUtils.isEmpty(returnList)) {
            ApiScenarioReferenceId saveItem = new ApiScenarioReferenceId();
            saveItem.setId(UUID.randomUUID().toString());
            saveItem.setApiScenarioId(scenario.getId());
            saveItem.setCreateTime(System.currentTimeMillis());
            saveItem.setCreateUserId(MsHashTreeConstants.ADMIN);
            returnList.add(saveItem);
        }
        return returnList;
    }

    /**
     * 转换接口定义指定路径及下属路径的所有数据
     * */
    public void convertApiScenarioByModuleId(String apiModuleId, String projectId,String goalProjectId){

        Set<String>  moduleIds = new TreeSet<>();
        moduleIds.add(apiModuleId);
        this.ObtainScenarioModuleChildrenId(apiModuleId,projectId,moduleIds);

        moduleIds.forEach(item-> {

            this.convertExternalScenario(item,projectId,goalProjectId);

            this.convertInternalScenario(item,projectId,goalProjectId);

        });

    }
    /**
     * 递归所有当前节点的子节点ID
     * */
    public void ObtainScenarioModuleChildrenId(String apiModuleId, String projectId,Set<String> ids){
        ApiScenarioModuleExample scenarioModuleExample = new ApiScenarioModuleExample();

        if(MeterSphereImportApplication.IMPORT_TYPE){
            scenarioModuleExample.createCriteria().andProjectIdEqualTo(projectId);
            List<ApiScenarioModule> childrenNodeId = apiScenarioModuleMapper.selectByExample(scenarioModuleExample);
            ids.addAll(childrenNodeId.stream().map(ApiScenarioModule :: getId).collect(Collectors.toList()));
            return;
        }
        scenarioModuleExample.clear();
        scenarioModuleExample.createCriteria().andParentIdEqualTo(apiModuleId);
        List<ApiScenarioModule> childrenNodeId = apiScenarioModuleMapper.selectByExample(scenarioModuleExample);
        childrenNodeId.forEach( item ->{

            ids.add(item.getId());
            this.ObtainScenarioModuleChildrenId(item.getId(),projectId,ids);
        });
    }

    /**
     * Scenario_转换
     * */
    public void convertExternalScenario(String scenarioModuleId, String projectId,String goalProjectId){
        ApiScenarioExample apiScenarioExample = new ApiScenarioExample();
        apiScenarioExample.createCriteria().andApiScenarioModuleIdEqualTo(scenarioModuleId).andStatusNotEqualTo(AdminConstants.TRASH_STATUS);
        List<ApiScenarioWithBLOBs> apiScenarios = apiScenarioMapper.selectByExampleWithBLOBs(apiScenarioExample);

        apiScenarios.forEach( apiScenario -> {
            this.externalScenario(apiScenario,projectId,goalProjectId);
        });
    }
    private void externalScenario (ApiScenarioWithBLOBs apiScenario,  String projectId, String goalProjectId) {


        String oldModuleId = apiScenario.getApiScenarioModuleId();

        ApiScenarioModule oldApiScenarioModule = apiScenarioModuleMapper.selectByPrimaryKey(oldModuleId);
        String oldModuleName = oldApiScenarioModule.getName();
        Integer oldLevel = oldApiScenarioModule.getLevel();

        ApiScenarioModule newApiScenarioModule = salveapiScenarioModuleMapper.selectByPrimaryKey(API_SCENARIO_MODULE.get(oldModuleId));

        String newModuleName = newApiScenarioModule.getName();
        Integer newLevel = newApiScenarioModule.getLevel();

        ApiScenarioExample apiScenarioExample = new ApiScenarioExample();
        apiScenarioExample.createCriteria()
                .andApiScenarioModuleIdEqualTo(API_SCENARIO_MODULE.get(oldModuleId))
                .andStatusNotEqualTo(AdminConstants.TRASH_STATUS)
                .andNameEqualTo(apiScenario.getName());

        List<ApiScenarioWithBLOBs> apiScenarios = salveapiScenarioMapper.selectByExampleWithBLOBs(apiScenarioExample);

        if (StringUtils.equals(oldModuleName, newModuleName) && oldLevel.equals(newLevel) && CollectionUtils.isNotEmpty(apiScenarios)) {
            ApiScenarioWithBLOBs apiScenarioB = apiScenarios.get(0);

            apiScenarioB.setUpdateTime(System.currentTimeMillis());
            apiScenarioB.setScenarioDefinition(apiScenario.getScenarioDefinition());

            this.convertEnvironment(apiScenario, apiScenarioB);
            salveapiScenarioMapper.updateByPrimaryKeySelective(apiScenarioB);

            API_SCENARIO_MAP.put(apiScenario.getId(), apiScenarioB.getId());
            return;
        }

        String newScenarioId = UUID.randomUUID().toString();

        ApiScenarioWithBLOBs apiScenarioC = new ApiScenarioWithBLOBs();

        ServiceUtils.copyProperties(apiScenario, apiScenarioC);

        apiScenarioC.setId(newScenarioId);
        apiScenarioC.setApiScenarioModuleId(API_SCENARIO_MODULE.get(oldModuleId));
        apiScenarioC.setProjectId(goalProjectId);
        apiScenarioC.setLastResult(null);
        apiScenarioC.setRefId(newScenarioId);
        apiScenarioC.setReportId(null);
        apiScenarioC.setVersionId(PROJECT_VERSION.get(apiScenario.getVersionId()));
        apiScenarioC.setCreateTime(System.currentTimeMillis());
        apiScenarioC.setUpdateTime(System.currentTimeMillis());
        if (apiScenarioC.getOrder() != null) {
            apiScenarioC.setOrder(apiScenarioC.getOrder() + SCENARIO_ORDER);
        }
        if (apiScenarioC.getNum() != null) {
            apiScenarioC.setNum(apiScenarioC.getNum() + SCENARIO_NUM);
        }
        String environmentJson = apiScenario.getEnvironmentJson();

        Map<String, String> envMap = JSONObject.parseObject(environmentJson, Map.class);
        if (envMap != null && envMap.size() > 0) {

            JSONObject jsonEnv = new JSONObject();

            envMap.forEach((key, value) -> {
                if (StringUtils.equals(projectId, key)) {
                    jsonEnv.put(goalProjectId, value);
                } else {
                    jsonEnv.put(key, value);
                }
            });
            apiScenarioC.setEnvironmentJson(JSONObject.toJSONString(this.convertEnvMap(environmentJson, projectId, goalProjectId)));
        }
        this.convertEnvironment(apiScenario, apiScenarioC);

        salveapiScenarioMapper.insertSelective(apiScenarioC);

        API_SCENARIO_MAP.put(apiScenario.getId(), newScenarioId);
    }
    private void convertEnvironment (ApiScenarioWithBLOBs source,  ApiScenarioWithBLOBs target){
        String environmentJson = source.getEnvironmentJson();

        Map<String,String> envMap = JSONObject.parseObject(environmentJson,Map.class);
        if(envMap != null && envMap.size() > 0){

            JSONObject jsonEnv  = new JSONObject();

            envMap.forEach((key, value) -> {
                if(StringUtils.equals(source.getProjectId(),key)){
                    if (StringUtils.isNotBlank(ENVIRONMENT.get(value))){
                        jsonEnv.put(target.getProjectId(),ENVIRONMENT.get(value));
                    }else{
                        jsonEnv.put(target.getProjectId(),value);
                    }
                }else{
                    jsonEnv.put(key,value);
                }
            });
            target.setEnvironmentJson(JSONObject.toJSONString(this.convertEnvMap(environmentJson,source.getProjectId(),target.getProjectId())));
        }
    }

    private void internalScenario (ApiScenarioWithBLOBs apiScenario,  String projectId, String goalProjectId){
        String scenarioDefinition = apiScenario.getScenarioDefinition();

        JSONObject definition = JSONObject.parseObject(scenarioDefinition);
        //场景内的scenarioDefinition ****
        if(definition != null){
            //外层数据转化
            definition.put("id",apiScenario.getId());
            definition.put("projectId",apiScenario.getProjectId());

            String environmentJson = definition.getString("environmentMap");
            definition.put("environmentMap",this.convertEnvMap(environmentJson,projectId,goalProjectId));
            //hashTree内层数据转化

            JSONArray hashTree = definition.getJSONArray(ElementConstants.HASH_TREE);

            //找出关联API&CASE并创建
            ApiNode apiNode = new ApiNode();
            this.relationshipsApiByHashTree(hashTree,apiNode,projectId);

            if(CollectionUtils.isNotEmpty(apiNode.getChildrenNode())){
                System.out.println("找出关联API&CASE并创建====start");
                this.compareAndCreateApi(apiNode,goalProjectId);
                System.out.println("找出关联API&CASE并创建====end");
            }
            //找出关联场景并创建
            ScenarioNode scenarioNode = new ScenarioNode();

            this.relationshipsByHashTree(hashTree,scenarioNode,projectId);

            if(CollectionUtils.isNotEmpty(scenarioNode.getChildrenNode())){

                this.compareAndCreate(scenarioNode,projectId,goalProjectId);
            }




            convertHashTree(hashTree,projectId,goalProjectId);

            apiScenario.setScenarioDefinition(JSONObject.toJSONString(definition));
        }

        salveapiScenarioMapper.updateByPrimaryKeySelective(apiScenario);

    }

    private void compareAndCreateApi(ApiNode childNode,  String goalProjectId){

        List<ApiNode> apiNodes = childNode.getChildrenNode();

        if(CollectionUtils.isNotEmpty(apiNodes)){

            apiNodes.forEach(apiNode -> {

                String type = apiNode.getType();


                if(StringUtils.equalsIgnoreCase(type,MsHashTreeConstants.CASE)){
                    if(StringUtils.isBlank(API_CASE_MAP.get(apiNode.getId()))){

                        ApiTestCaseWithBLOBs apiTestCaseWithBLOBs = apiTestCaseMapper.selectByPrimaryKey(apiNode.getId());
                        if(apiTestCaseWithBLOBs == null){
                           return;
                        }
                        this.caseRepeat(apiTestCaseWithBLOBs,goalProjectId);

                    }
                }else{
                    if(StringUtils.isBlank(API_DEFINITION_MAP.get(apiNode.getId()))){

                        ApiDefinitionWithBLOBs apiDefinitionWithBLOBs = apiDefinitionMapper.selectByPrimaryKey(apiNode.getId());
                        if(apiDefinitionWithBLOBs == null){
                            return;
                        }
                        this.apiRepeat(apiDefinitionWithBLOBs,goalProjectId);

                    }
                }

                if(CollectionUtils.isNotEmpty(apiNode.getChildrenNode())){
                    this.compareAndCreateApi(apiNode,goalProjectId);
                }
            });
        }
    }

    private void compareAndCreate(ScenarioNode childrenNode,String projectId, String goalProjectId){

        List<ScenarioNode> scenarioNodes = childrenNode.getChildrenNode();

        if(CollectionUtils.isNotEmpty(scenarioNodes)){

            scenarioNodes.forEach(scenarioNode -> {

                if(StringUtils.isBlank(API_SCENARIO_MAP.get(scenarioNode.getId()))){


                    ApiScenarioWithBLOBs apiScenario = apiScenarioMapper.selectByPrimaryKey(scenarioNode.getId());

                    if(apiScenario != null){
                        this.externalScenario(apiScenario,projectId,goalProjectId);


                        apiScenario = salveapiScenarioMapper.selectByPrimaryKey(API_SCENARIO_MAP.get(scenarioNode.getId()));

                        this.internalScenario(apiScenario,projectId,goalProjectId);

                        if(CollectionUtils.isNotEmpty(scenarioNode.getChildrenNode())){
                            compareAndCreate(scenarioNode,projectId,goalProjectId);
                        }
                    }
                }
            });
        }
    }
    /**
     * Scenario_转换
     * */
    public void convertInternalScenario(String scenarioModuleId, String projectId,String goalProjectId){
        ApiScenarioExample apiScenarioExample = new ApiScenarioExample();
        apiScenarioExample.createCriteria().andApiScenarioModuleIdEqualTo(API_SCENARIO_MODULE.get(scenarioModuleId)).andStatusNotEqualTo(AdminConstants.TRASH_STATUS);
        List<ApiScenarioWithBLOBs> apiScenarios = salveapiScenarioMapper.selectByExampleWithBLOBs(apiScenarioExample);

        apiScenarios.forEach( apiScenario -> {
            this.internalScenario(apiScenario,projectId,goalProjectId);
        });
    }




    /**
     * 递归处理HashTree
     */
    public void convertHashTree(JSONArray hashTree ,String projectId,String goalProjectId){

        if(hashTree == null || hashTree.size()== 0){
            return ;
        }

        for(int i = 0;i < hashTree.size(); i++){

            JSONObject element = hashTree.getJSONObject(i);
            if(element == null){
                continue;
            }

            String oldId = element.getString("id");

            if(element.containsKey(ElementConstants.PROJECT_ID)
                    && StringUtils.equals(element.getString(ElementConstants.PROJECT_ID),projectId)){

                element.put(ElementConstants.PROJECT_ID,goalProjectId);

                if (element.containsKey(ElementConstants.TYPE) && StringUtils.isNotBlank(oldId)){

                    if(StringUtils.equals(ElementConstants.HTTP_SAMPLER,element.getString(ElementConstants.TYPE)) && element.containsKey(ElementConstants.REF_TYPE)){
                        if(StringUtils.equals(element.getString(ElementConstants.REF_TYPE),ElementConstants.CASE)){
                            element.put("id",API_CASE_MAP.get(oldId));
                        }else{
                            element.put("id",API_DEFINITION_MAP.get(oldId));
                        }
                    }

                    if(StringUtils.equalsIgnoreCase(ElementConstants.SCENARIO,element.getString(ElementConstants.TYPE))){
                        element.put("id",API_SCENARIO_MAP.get(oldId));
                    }
                }
            }
            if(element.containsKey(ElementConstants.HASH_TREE)){
                convertHashTree(element.getJSONArray(ElementConstants.HASH_TREE),projectId,goalProjectId);
            }
        }

    }

    /**
     * 只找出场景直接依赖
     *
     * @param hashTree
     * @param scenarioNode
     */
    public void relationshipsByHashTree(JSONArray hashTree, ScenarioNode scenarioNode, String projectId) {

        if(CollectionUtils.isNotEmpty(hashTree)){
            for (int i = 0; i < hashTree.size(); i++) {
                JSONObject element = hashTree.getJSONObject(i);

                if(StringUtils.isBlank(element.getString(MsHashTreeConstants.ID))){
                    continue;
                }
                if (element != null && element.containsKey(ElementConstants.TYPE)
                        && StringUtils.equals(element.getString(ElementConstants.TYPE), ElementConstants.SCENARIO)
                        && element.containsKey(MsHashTreeConstants.REFERENCED)) {
                    if (StringUtils.equals(element.getString(ElementConstants.PROJECT_ID),projectId)) {


                        if(StringUtils.isNotBlank(API_SCENARIO_MAP.get(element.getString(MsHashTreeConstants.ID)))){
                            continue;
                        }

                        ScenarioNode childNode = new ScenarioNode();
                        childNode.setId(element.getString(MsHashTreeConstants.ID));
                        scenarioNode.getChildrenNode().add(childNode);

                        if (element.containsKey(ElementConstants.HASH_TREE)) {
                            JSONArray elementJSONArray = element.getJSONArray(ElementConstants.HASH_TREE);
                            relationshipsByHashTree(elementJSONArray, childNode, projectId);
                        }
                    }
                }else {

                    if (element.containsKey(ElementConstants.HASH_TREE)) {
                        JSONArray elementJSONArray = element.getJSONArray(ElementConstants.HASH_TREE);
                        ScenarioNode childNode = new ScenarioNode();
                        relationshipsByHashTree(elementJSONArray, childNode, projectId);
                    }
                }
            }
        }
    }
    /**
     * 只找出本项目的APi依赖
     *
     * @param hashTree
     * @param apiNode
     */
    public void relationshipsApiByHashTree(JSONArray hashTree, ApiNode apiNode, String projectId) {

        if(CollectionUtils.isNotEmpty(hashTree)){
            for (int i = 0; i < hashTree.size(); i++) {
                JSONObject element = hashTree.getJSONObject(i);

                if(StringUtils.isBlank(element.getString(MsHashTreeConstants.ID))){
                    continue;
                }

                if (element != null && element.containsKey(ElementConstants.TYPE)
                        && StringUtils.equals(element.getString(ElementConstants.TYPE), ElementConstants.HTTP_SAMPLER)
                        && element.containsKey(MsHashTreeConstants.REFERENCED)
                        && StringUtils.isNotBlank(element.getString(MsHashTreeConstants.REFERENCED))
                        && element.containsKey(MsHashTreeConstants.REF_TYPE)
                        && StringUtils.isNotBlank(element.getString(MsHashTreeConstants.REF_TYPE))) {

                    if (StringUtils.equals(element.getString(ElementConstants.PROJECT_ID),projectId)) {

                        if(StringUtils.equalsIgnoreCase(element.getString(MsHashTreeConstants.REF_TYPE),MsHashTreeConstants.CASE)){
                            if(StringUtils.isNotBlank(API_CASE_MAP.get(element.getString(MsHashTreeConstants.ID)))){
                                continue;
                            }
                        }else{
                            if(StringUtils.isNotBlank(API_DEFINITION_MAP.get(element.getString(MsHashTreeConstants.ID)))){
                                continue;
                            }
                        }

                        ApiNode childNode = new ApiNode();
                        childNode.setId(element.getString(MsHashTreeConstants.ID));
                        childNode.setType(element.getString(MsHashTreeConstants.REF_TYPE));
                        apiNode.getChildrenNode().add(childNode);

                        if (element.containsKey(ElementConstants.HASH_TREE)) {
                            JSONArray elementJSONArray = element.getJSONArray(ElementConstants.HASH_TREE);
                            relationshipsApiByHashTree(elementJSONArray, childNode, projectId);
                        }
                    }
                }else {

                    if (element.containsKey(ElementConstants.HASH_TREE)) {
                        JSONArray elementJSONArray = element.getJSONArray(ElementConstants.HASH_TREE);
                        ApiNode childNode = new ApiNode();
                        relationshipsApiByHashTree(elementJSONArray, childNode, projectId);
                    }
                }
            }
        }
    }

    /**
     *处理内层的环境属性
     */
    public JSONObject convertEnvMap(String environmentJson,String projectId,String goalProjectId){
        Map<String,String> environmentMap = JSONObject.parseObject(environmentJson,Map.class);
        if(environmentMap != null && environmentMap.size() > 0){
            JSONObject jsonEnv  = new JSONObject();
            environmentMap.forEach((key, value) -> {
                if(StringUtils.equals(projectId,key)){
                    if (StringUtils.isNotBlank(ENVIRONMENT.get(value))){
                        jsonEnv.put(goalProjectId,ENVIRONMENT.get(value));
                    }else{
                        jsonEnv.put(goalProjectId,value);
                    }
                }else{
                    jsonEnv.put(key,value);
                }
            });
            return jsonEnv;
        }

        return new JSONObject();

    }

    /**
     * 环境转换
     * */
    public void convertEnv(List<String> envIds,String projectId, String goalProjectId){

        envIds.forEach(envId ->{

            ApiTestEnvironmentWithBLOBs envA = apiTestEnvironmentMapper.selectByPrimaryKey(envId);

            String envName = envA.getName();
            String projectIdSubFour = projectId.substring(projectId.length() - 4);
            if(envName.length() > 4){
                String envNameSubFour = envName.substring(envName.length() - 4);
                if(!StringUtils.equals(projectIdSubFour,envNameSubFour)){
                    envName = envName + "-" + projectIdSubFour;
                }
            }else{
                envName = envName + "-" + projectIdSubFour;
            }
            ApiTestEnvironmentExample example = new ApiTestEnvironmentExample();
            example.createCriteria().andProjectIdEqualTo(goalProjectId).andNameEqualTo(envName);
            List<ApiTestEnvironmentWithBLOBs> environmentList = salveapiTestEnvironmentMapper.selectByExampleWithBLOBs(example);

            if (CollectionUtils.isNotEmpty(environmentList)){
                ApiTestEnvironmentWithBLOBs envB = environmentList.get(0);
                this.changeEnvironmentConfig(envA);
                envB.setConfig(envA.getConfig());
                envB.setUpdateTime(envA.getUpdateTime());
                salveapiTestEnvironmentMapper.updateByPrimaryKeyWithBLOBs(envB);
                ENVIRONMENT.put(envId,envB.getId());
            }else{
                envA.setName(envName);
                envA.setId(UUID.randomUUID().toString());
                envA.setProjectId(goalProjectId);
                this.changeEnvironmentConfig(envA);
                envA.setCreateTime(System.currentTimeMillis());
                salveapiTestEnvironmentMapper.insertSelective(envA);
                //ENVIRONMENT_MODULE.add(envA.getId());

                ENVIRONMENT.put(envId,envA.getId());
            }
        });
    }
    private void changeEnvironmentConfig(ApiTestEnvironmentWithBLOBs envA){
        JSONObject config = JSONObject.parseObject(envA.getConfig());
        JSONObject httpConfig = config.getJSONObject("httpConfig");
        JSONArray conditions = httpConfig.getJSONArray("conditions");
        if(CollectionUtils.isNotEmpty(conditions)){
            for (int j = 0; j<conditions.size(); j++ ){
                JSONObject one = conditions.getJSONObject(j);
                String type = one.getString("type");
                if(StringUtils.isNotBlank(type) && StringUtils.equals(AdminConstants.HTTP_CONFIG_MODULE,type)){
                    JSONArray details = one.getJSONArray("details");
                    for (int i = 0; i<details.size(); i++ ){
                        JSONObject detail = details.getJSONObject(i);
                        String value = detail.getString("value");
                        String newValue = API_MODULE.get(value);
                        detail.put("value",newValue);
                    }
                    one.put("details",details);
                }
            }
        }
        envA.setConfig(JSONObject.toJSONString(config));
        envA.setUpdateTime(System.currentTimeMillis());
    }
    public void convertEnv2(){

        System.out.println("源环境ID" + JSONObject.toJSONString(ENVIRONMENT.keySet()));
        System.out.println("目标环境ID" + JSONObject.toJSONString(ENVIRONMENT.values()));

    }

    public void convertSQLToProject(String sqlText){

    }
}
