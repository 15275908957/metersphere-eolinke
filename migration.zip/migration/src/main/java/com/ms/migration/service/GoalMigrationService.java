package com.ms.migration.service;

import com.ms.migration.annotation.DS;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.*;
import com.ms.migration.salvemapper.*;
import com.ms.migration.tools.ServiceUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

/**
 * @Classname GoalMigrationService
 * @Description TODO
 * @Date 2023/9/5 下午4:52
 * @Created by liujianqiang
 */
@Service
@DS(DataSourceConstants.DS_KEY_SLAVE)
public class GoalMigrationService {
    @Autowired
    private SalveWorkspaceMapper workspaceMapper;
    @Autowired
    private SalveProjectMapper projectMapper;
    @Autowired
    private SalveApiTestEnvironmentMapper apiTestEnvironmentMapper;
    @Autowired
    private SalveMigrationMapper migrationMapper;


    /**
     * 获取空间信息
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    public List<Workspace> getWorkspaces(){
        List<Workspace> workspaces = workspaceMapper.selectByExample(null);
        return workspaces;
    }
    /**
     * 获取项目信息
     */
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    public List<Project> getMSProject(String workSpaceId){
        ProjectExample example = new ProjectExample();
        example.createCriteria().andWorkspaceIdEqualTo(workSpaceId);
        example.setOrderByClause("name");
        List<Project> projects = projectMapper.selectByExample(example);
        return projects;
    }

    /**
     * 获取环境列表信息
     */
    public List<ApiTestEnvironment> getEnvironments(String projectId){

        ApiTestEnvironmentExample example = new ApiTestEnvironmentExample();
        example.createCriteria().andProjectIdEqualTo(projectId);
        List<ApiTestEnvironment> apiTestEnvironments = apiTestEnvironmentMapper.selectByExample(example);
        return apiTestEnvironments;
    }
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    public Long getImportDefinitionNextOrder(String projectId) {
        Long order = ServiceUtils.getNextOrder(projectId, migrationMapper::getDefinitionLastOrder);
        return getOrderNext(order);
    }
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    public Long getImportCaseNextOrder(String projectId) {
        Long order = ServiceUtils.getNextOrder(projectId, migrationMapper::getCaseLastOrder);
        return getOrderNext(order);
    }
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    public Long getImportScenarioNextOrder(String projectId) {
        Long order = ServiceUtils.getNextOrder(projectId, migrationMapper::getScenarioLastOrder);
        return getOrderNext(order);
    }
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    private Long getOrderNext(Long order){
        if (order == null) {
            return 0L;
        }else{
            order = order - ServiceUtils.ORDER_STEP;
        }
        return order;
    }
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    public int getScenarioNextNum(String projectId) {
        Integer num = migrationMapper.getScenarioNextNum(projectId);
        return getNumNext(num);
    }
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    public int getCaseNextNum(String definitionId) {
        Integer apiTestCase = migrationMapper.getCaseNextNum(definitionId);
        Integer apiDefinitionWithBLOBs = migrationMapper.getDefinitionConcurrentNum(definitionId);
        int apiDefinitionNum = 0;
        if (apiDefinitionWithBLOBs != null) {
            apiDefinitionNum = apiDefinitionWithBLOBs * 1000 + 1;
        }
        if (apiTestCase == null) {
            return apiDefinitionNum;
        } else {
            return apiDefinitionNum + 1;
        }
    }
    @DS(DataSourceConstants.DS_KEY_SLAVE)
    public int getDefinitionNextNum(String projectId) {

        Integer num = migrationMapper.getDefinitionNextNum(projectId);
        return getNumNext(num);
    }

    private Integer getNumNext(Integer num){
        if (num == null) {
            return 0;
        }else{
            num = num - 100001;
        }
        return num;
    }
}
