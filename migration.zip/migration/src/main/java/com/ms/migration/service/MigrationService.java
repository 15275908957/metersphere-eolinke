package com.ms.migration.service;


import com.ms.migration.annotation.DS;
import com.ms.migration.constants.AdminConstants;
import com.ms.migration.constants.DataSourceConstants;
import com.ms.migration.domain.*;
import com.ms.migration.entity.ApiModuleNode;
import com.ms.migration.entity.ScenarioModuleNode;
import com.ms.migration.mapper.*;
import com.ms.migration.tools.ServiceUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author liujianqiang
 * @Classname Migration
 * @Description TODO
 * @Date 2023/8/7 下午6:01
 * @Created by liujianqiang
 */
@Service
@DS(DataSourceConstants.DS_KEY_MASTER)
public class MigrationService {
    @Resource
    private WorkspaceMapper workspaceMapper;
    @Resource
    private ProjectMapper projectMapper;
    @Resource
    private ApiModuleMapper apiModuleMapper;
    @Resource
    private ApiScenarioModuleMapper apiScenarioModuleMapper;
    @Resource
    private ApiTestEnvironmentMapper apiTestEnvironmentMapper;
    @Resource
    private MigrationMapper migrationMapper;

    /**
     * 获取空间信息
     */
    public List<Workspace> getWorkspaces(){
        List<Workspace> workspaces = workspaceMapper.selectByExample(null);
        return workspaces;
    }
    /**
     * 获取项目信息
     */
    public List<Project> getMSProject(String workSpaceId){
        ProjectExample example = new ProjectExample();
        example.createCriteria().andWorkspaceIdEqualTo(workSpaceId);
        example.setOrderByClause("name");
        List<Project> projects = projectMapper.selectByExample(example);
        return projects;
    }
    /**
     * 获取接口定义模块信息
     */
    public List<ApiModule> getApiModule(String projectId){
        ApiModuleExample example = new ApiModuleExample();
        example.setOrderByClause("name");
        example.createCriteria().andProjectIdEqualTo(projectId).andProtocolEqualTo(AdminConstants.PROTOCOL_HTTP);
        List<ApiModule> apiModules = apiModuleMapper.selectByExample(example);
        return apiModules;
    }

    /**
     * 获取接口定义模块树形信息
     */
    public List<ApiModuleNode> getApiModuleNode(String projectId){
        List<ApiModule> apiModuleList =  this.getApiModule(projectId);
        List<ApiModuleNode> apiModuleNodes = apiModuleList.stream()
                .map(a -> {
                    ApiModuleNode b = new ApiModuleNode();
                    ServiceUtils.copyProperties(a, b);
                    return b;
                })
                .collect(Collectors.toList());
        return buildTree(apiModuleNodes);
    }

    public List<ApiModuleNode> buildTree(List<ApiModuleNode> objects) {
        return buildTree(null, objects);
    }

    private List<ApiModuleNode> buildTree(String parentId, List<ApiModuleNode> objects) {
        return objects.stream()
                .filter(obj -> StringUtils.equals(obj.getParentId(),parentId))
                .map(obj -> {
                    List<ApiModuleNode> children = buildTree(obj.getId(), objects);
                    if(CollectionUtils.isEmpty(obj.getChildren())){
                        obj.setChildren(new ArrayList<>());
                    }
                    obj.getChildren().addAll(children);
                    return obj;
                }).collect(Collectors.toList());
    }
    /**
     * 获取接口场景模块信息
     */
    public List<ApiScenarioModule> getApiScenarioModule(String projectId){
        ApiScenarioModuleExample example = new ApiScenarioModuleExample();
        example.createCriteria().andProjectIdEqualTo(projectId);
        List<ApiScenarioModule> apiScenarioModules = apiScenarioModuleMapper.selectByExample(example);
        return apiScenarioModules;
    }

    /**
     * 获取接口场景模块树形信息
     */
    public List<ScenarioModuleNode> getApiScenarioModuleNode(String projectId){
        List<ApiScenarioModule> apiScenarioModuleList =  this.getApiScenarioModule(projectId);
        List<ScenarioModuleNode> apiModuleNodes = apiScenarioModuleList.stream()
                .map(a -> {
                    ScenarioModuleNode b = new ScenarioModuleNode();
                    ServiceUtils.copyProperties(a,b);
                    return b;
                })
                .collect(Collectors.toList());
        return buildScenarioModuleTree(apiModuleNodes);
    }
    public List<ScenarioModuleNode> buildScenarioModuleTree(List<ScenarioModuleNode> objects) {
        return buildScenarioModuleTree(null, objects);
    }

    private List<ScenarioModuleNode> buildScenarioModuleTree(String parentId, List<ScenarioModuleNode> objects) {
        return objects.stream()
                .filter(obj -> StringUtils.equals(obj.getParentId(),parentId))
                .map(obj -> {
                    List<ScenarioModuleNode> children = buildScenarioModuleTree(obj.getId(), objects);
                    if(CollectionUtils.isEmpty(obj.getChildren())){
                        obj.setChildren(new ArrayList<>());
                    }
                    obj.getChildren().addAll(children);
                    return obj;
                })
                .collect(Collectors.toList());
    }

    /**
     * 获取环境列表信息
     */
    public List<ApiTestEnvironment> getEnvironments(String projectId){

        ApiTestEnvironmentExample example = new ApiTestEnvironmentExample();
        example.createCriteria().andProjectIdEqualTo(projectId);
        example.setOrderByClause("name");
        List<ApiTestEnvironment> apiTestEnvironments = apiTestEnvironmentMapper.selectByExample(example);
        return apiTestEnvironments;
    }

    public Long getImportDefinitionNextOrder(String projectId) {
        Long order = ServiceUtils.getNextOrder(projectId, migrationMapper::getDefinitionLastOrder);
        return getOrderNext(order);
    }

    public Long getImportCaseNextOrder(String projectId) {
        Long order = ServiceUtils.getNextOrder(projectId, migrationMapper::getCaseLastOrder);
        return getOrderNext(order);
    }

    public Long getImportScenarioNextOrder(String projectId) {
        Long order = ServiceUtils.getNextOrder(projectId, migrationMapper::getScenarioLastOrder);
        return getOrderNext(order);
    }

    private Long getOrderNext(Long order){
        if (order == null) {
            return 0L;
        }else{
            order = order - ServiceUtils.ORDER_STEP;
        }
        return order;
    }

    public int getScenarioNextNum(String projectId) {
        Integer num = migrationMapper.getScenarioNextNum(projectId);
        return getNumNext(num);
    }
    public int getCaseNextNum(String definitionId) {
        Integer apiTestCase = migrationMapper.getCaseNextNum(definitionId);
        Integer apiDefinitionWithBLOBs = migrationMapper.getDefinitionConcurrentNum(definitionId);
        int apiDefinitionNum = 0;
        if (apiDefinitionWithBLOBs != null) {
            apiDefinitionNum = apiDefinitionWithBLOBs * 1000 + 1;
        }
        if (apiTestCase == null) {
            return apiDefinitionNum;
        } else {
            return apiDefinitionNum + 1;
        }
    }

    public int getDefinitionNextNum(String projectId) {

        Integer num = migrationMapper.getDefinitionNextNum(projectId);
        return getNumNext(num);
    }
    private Integer getNumNext(Integer num){
        if (num == null) {
            return 0;
        }else{
            num = num - 100001;
        }
        return num;
    }

}
