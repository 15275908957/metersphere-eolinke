package com.ms.migration.swing;
import javax.swing.*;
import java.awt.*;
/**
 * @author liujianqiang
 * @Classname CheckComboBoxRenderer
 * @Description TODO
 * @Date 2023/8/14 下午5:47
 * @Created by liujianqiang
 */

public class CheckBoxListCellRenderer implements ListCellRenderer<JCheckBox> {
    @Override
    public Component getListCellRendererComponent(JList<? extends JCheckBox> list, JCheckBox value, int index, boolean isSelected, boolean cellHasFocus) {
        JCheckBox checkbox = value;
        checkbox.setBackground(isSelected ? list.getSelectionBackground() : list.getBackground());
        checkbox.setForeground(isSelected ? list.getSelectionForeground() : list.getForeground());
        return checkbox;
    }
}