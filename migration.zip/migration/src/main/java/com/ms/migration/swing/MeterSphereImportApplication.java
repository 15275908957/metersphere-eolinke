package com.ms.migration.swing;


import com.alibaba.fastjson2.JSONObject;
import com.alibaba.fastjson2.util.DateUtils;
import com.ms.migration.constants.AdminConstants;
import com.ms.migration.domain.ApiTestEnvironment;
import com.ms.migration.domain.Project;
import com.ms.migration.domain.Workspace;
import com.ms.migration.entity.ApiModuleNode;
import com.ms.migration.entity.ScenarioModuleNode;
import com.ms.migration.service.ConvertDataService;
import com.ms.migration.service.GoalMigrationService;
import com.ms.migration.service.MigrationService;
import com.ms.migration.tools.UseFile;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;


/**
 * @author liujianqiang
 */
@Component
public class MeterSphereImportApplication {

    @Autowired
    private MigrationService migrationService;
    @Autowired
    private ConvertDataService convertEnvService;

    @Autowired
    private GoalMigrationService goalMigrationService;

    private static JLabel SQL文件路径=new JLabel("SQL文件路径：");
    private static JTextField SQL文件=new JTextField(25);
    private static JButton SQL按钮=new JButton("选择SQL文件");

    private static JButton 下一步=new JButton("进入 转化配置 页面");
    private static JTextArea 登录提示信息=new JTextArea("请先填写登录信息，再进行转换配置，配置信息会保存到当前目录，后续跳过本步骤。");


    private static JLabel 导入模式=new JLabel("导入模式：");
    private static JComboBox 导入模式下拉框=new JComboBox();

    private static JLabel 选择环境 =new JLabel("选择环境：");
    private static JComboBox<JCheckBox> 环境下拉框 = new JComboBox();

    private static JLabel 选择源项目=new JLabel("选择源项目：");
    private static JComboBox 源项目下拉框=new JComboBox();

    private static JLabel 选择源接口模块=new JLabel("选择源接口模块：");
    private static JComboBox 源接口模块下拉框=new JComboBox();

    private static JLabel 选择源场景模块=new JLabel("选择源场景模块：");
    private static JComboBox 源场景模块下拉框=new JComboBox();

    private static JLabel 选择源工作空间=new JLabel("选择源工作空间：");
    private static JComboBox 源工作空间下拉框=new JComboBox();


    private static JLabel 选择目标项目=new JLabel("选择目标项目：");
    private static JComboBox 目标项目下拉框=new JComboBox();

//    private static JLabel 选择目标接口模块=new JLabel("选择目标接口模块：");
//    private static JComboBox 目标接口模块下拉框=new JComboBox();
//
//    private static JLabel 选择目标场景模块=new JLabel("选择目标场景模块：");
//    private static JComboBox 目标场景模块下拉框=new JComboBox();

    private static JLabel 选择目标工作空间=new JLabel("选择目标工作空间：");
    private static JComboBox 目标工作空间下拉框=new JComboBox();


    public static Boolean IMPORT_TYPE = false;
    
    private static JLabel 迁移进度=new JLabel("迁移进度  0%");

    private static JButton 迁移=new JButton("一键迁移");

    private static JTextArea 提示信息=new JTextArea("所有信息为必填信息，迁移进度到达100%，迁移完成。");


    public JFrame 容器 = null;
    public JPanel 面板 = null;
    public ConcurrentHashMap<String, String> environment = new ConcurrentHashMap<>();
    public ConcurrentHashMap<String, String> workspace = new ConcurrentHashMap<>();
    public ConcurrentHashMap<String, String> projectMap = new ConcurrentHashMap<>();
    public ConcurrentHashMap<String, String> 接口模块 = new ConcurrentHashMap<>();
    public ConcurrentHashMap<String, ApiModuleNode> apiMap = new ConcurrentHashMap<>();

    public ConcurrentHashMap<String, String> 场景模块 = new ConcurrentHashMap<>();
    public ConcurrentHashMap<String, ScenarioModuleNode> contextMap = new ConcurrentHashMap<>();


    public ConcurrentHashMap<String, String> goalWorkspace = new ConcurrentHashMap<>();
    public ConcurrentHashMap<String, String> goalProjectMap = new ConcurrentHashMap<>();
//    public ConcurrentHashMap<String, String> 目标接口模块 = new ConcurrentHashMap<>();
//    public ConcurrentHashMap<String, ApiModuleNode> goalApiMap = new ConcurrentHashMap<>();
//
//    public ConcurrentHashMap<String, String> 目标场景模块 = new ConcurrentHashMap<>();
//    public ConcurrentHashMap<String, ScenarioModuleNode> goalContextMap = new ConcurrentHashMap<>();


    public ConcurrentHashMap<String, String> importTypeMap = new ConcurrentHashMap<>();


    public String logFileName;

    {
        logFileName = "log" + DateUtils.format(new Date());
        importTypeMap.put("全部", "fullCoverage");
        importTypeMap.put("指定", "incrementalMerge");
    }

    public void 获取初始化SQL数据面板(JPanel jPanel){
        SQL文件路径.setBounds(50,20,300,30);
        SQL文件.setBounds(110,50,360,30);
        SQL按钮.setBounds(480,50,100,30);

        下一步.setBounds(210,50,300,30);

        登录提示信息.setBounds(50,150,500,100);
        登录提示信息.setForeground(Color.red);
        登录提示信息.setBackground(null);
        登录提示信息.setBorder(null);

        jPanel.add(SQL文件路径);
        jPanel.add(SQL文件);
        jPanel.add(SQL按钮);



        下一步.addActionListener(new nextStep());
        jPanel.add(下一步);
        jPanel.add(登录提示信息);
    }
    public class nextStep implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent arg0)
        {
            下一步.setEnabled(false);
            try {
                String SQL路径 = SQL文件路径.getText();
                String SQL文件 = UseFile.readTxt(SQL路径);


            }catch (Exception e){
                e.printStackTrace();
//                wLog(e.getMessage());
                登录提示信息.setText("转化SLQ文件失败，请查看SQL文件是否正确。\n返回信息：\n"+e.getMessage());
                return;
            }finally {
                下一步.setEnabled(true);
            }

            面板.removeAll();
            获取面板(面板);
            面板.validate();
            面板.repaint();
        }
    }
    public void 获取面板(JPanel panel)
    {


        导入模式.setBounds(20,50,100,30);
        导入模式下拉框.setBounds(108,50,365,30);

        选择源工作空间.setBounds(20,80,100,30);
        源工作空间下拉框.setBounds(108,80,365,30);

        选择源项目.setBounds(20,110,100,30);
        源项目下拉框.setBounds(108,110,365,30);

        选择环境.setBounds(20,140,100,30);
        环境下拉框.setBounds(108,140,365,30);

        选择源接口模块.setBounds(20,170,100,30);
        源接口模块下拉框.setBounds(108,170,365,30);

        选择源场景模块.setBounds(20,200,100,30);
        源场景模块下拉框.setBounds(108,200,365,30);


        选择目标工作空间.setBounds(20,250,100,30);
        目标工作空间下拉框.setBounds(108,250,365,30);

        选择目标项目.setBounds(20,280,100,30);
        目标项目下拉框.setBounds(108,280,365,30);

//        选择目标接口模块.setBounds(20,310,100,30);
//        目标接口模块下拉框.setBounds(108,310,365,30);
//
//        选择目标场景模块.setBounds(20,340,100,30);
//        目标场景模块下拉框.setBounds(108,340,365,30);

        迁移.setBounds(485,80,90,90);
        迁移进度.setBounds(487,340,100,30);
        提示信息.setBounds(20,370,600,100);
        提示信息.setForeground(Color.red);
        提示信息.setBackground(null);
        提示信息.setBorder(null);

        try{
            panel.add(导入模式);

            导入模式下拉框.addItem("全部");
            导入模式下拉框.addItem("指定");

            panel.add(导入模式下拉框);
            //导入模式下拉框.setSelectedIndex(0);

            // 源数据选择
            panel.add(选择源工作空间);
            panel.add(源工作空间下拉框);

            panel.add(选择源项目);
            panel.add(源项目下拉框);

            panel.add(选择环境);
            panel.add(环境下拉框);

            Set<String> project = getMSWorkSpace();

            Iterator<String> pro = project.iterator();
            while (pro.hasNext()){
                源工作空间下拉框.addItem(pro.next());
            }

            源工作空间下拉框.addActionListener(e -> {
                源项目下拉框.removeAllItems();
                projectMap.clear();

                JComboBox cb = (JComboBox) e.getSource();
                //获得选择源项目
                String itemString = (String) cb.getSelectedItem();
                String workSpaceId = workspace.get(itemString);
                List<Project> projectArray = getMSProject(workSpaceId);

                projectMap = new ConcurrentHashMap<>();
                for(int i = 0 ; i < projectArray.size(); i++){
                    Project temp = projectArray.get(i);
                    projectMap.put(temp.getName(), temp.getId());
                }
                源项目下拉框.removeAllItems();
                for(int i = 0 ; i < projectArray.size(); i++){
                    Project temp = projectArray.get(i);
                    源项目下拉框.addItem(temp.getName());
                }
            });
            源工作空间下拉框.setSelectedIndex(0);

            源项目下拉框.addActionListener(e -> {
                源接口模块下拉框.removeAllItems();
                源场景模块下拉框.removeAllItems();
                环境下拉框.removeAllItems();

                接口模块.clear();
                场景模块.clear();
                environment.clear();

                JComboBox cb = (JComboBox) e.getSource();
                String itemString = (String) cb.getSelectedItem();
                if(itemString == null) {
                    return;
                }
                String projectId = projectMap.get(itemString);

                List<ApiModuleNode> apiModuleArray = getAPIModule(projectId);
                loadAPIModule(apiModuleArray);
                List<ScenarioModuleNode> contentModuleArray = getContentModule(projectId);
                loadContestModule(contentModuleArray);
                getEnvironmentModule(projectId);

                JButton button = new JButton("Select");
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        StringBuilder selectedOptions = new StringBuilder();
                        for (int i = 0; i < 环境下拉框.getItemCount(); i++) {
                            JCheckBox checkbox = 环境下拉框.getItemAt(i);
                            if (checkbox.isSelected()) {
                                selectedOptions.append(checkbox.getText()).append(", ");
                            }
                        }
                        if (selectedOptions.length() > 0) {
                            selectedOptions.delete(selectedOptions.length() - 2, selectedOptions.length());
                        }
                    }
                });

                panel.add(button);

            });
            源项目下拉框.setSelectedIndex(0);

            环境下拉框.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (环境下拉框.getItemCount() == 0){
                        return;
                    }
                    JComboBox<JCheckBox> source = (JComboBox<JCheckBox>) e.getSource();
                    JCheckBox selectedCheckbox = source.getItemAt(source.getSelectedIndex());
                    selectedCheckbox.setSelected(!selectedCheckbox.isSelected());
                }
            });

            环境下拉框.setRenderer(new CheckBoxListCellRenderer());

            panel.add(选择源接口模块);
            panel.add(源接口模块下拉框);

            panel.add(选择源场景模块);
            panel.add(源场景模块下拉框);

            // 目标数据选择

            panel.add(选择目标工作空间);
            panel.add(目标工作空间下拉框);

            panel.add(选择目标项目);
            panel.add(目标项目下拉框);

            Set<String> GoalProject = getGoalMSWorkSpace();

            Iterator<String> GoalPro = GoalProject.iterator();
            while (GoalPro.hasNext()){
                目标工作空间下拉框.addItem(GoalPro.next());
            }

            目标工作空间下拉框.addActionListener(e -> {

                目标项目下拉框.removeAllItems();
                goalProjectMap.clear();
                JComboBox cb = (JComboBox) e.getSource();
                //获得选择源项目
                String itemString = (String) cb.getSelectedItem();
                String workSpaceId = goalWorkspace.get(itemString);
                List<Project> projectArray = getMSGoalProject(workSpaceId);

                goalProjectMap = new ConcurrentHashMap<>();
                for(int i = 0 ; i < projectArray.size(); i++){
                    Project temp = projectArray.get(i);
                    goalProjectMap.put(temp.getName(), temp.getId());
                }
                目标项目下拉框.removeAllItems();
                for(int i = 0 ; i < projectArray.size(); i++){
                    Project temp = projectArray.get(i);

//                    String sourceName = String.valueOf(源项目下拉框.getSelectedItem());

//                    if(!StringUtils.equals(temp.getName(),sourceName)){
                        目标项目下拉框.addItem(temp.getName());
//                    }
                }
            });
            //目标工作空间下拉框.setSelectedIndex(0);

//            目标项目下拉框.addActionListener(e -> {
//                目标接口模块下拉框.removeAllItems();
//                目标场景模块下拉框.removeAllItems();
//
//                JComboBox cb = (JComboBox) e.getSource();
//                String itemString = (String) cb.getSelectedItem();
//                if(itemString == null) {
//                    return;
//                }
//                String projectId = goalProjectMap.get(itemString);
//
//                List<ApiModuleNode> apiModuleArray = getAPIModule(projectId);
//                goalLoadAPIModule(apiModuleArray);
//                List<ScenarioModuleNode> contentModuleArray = getContentModule(projectId);
//                goalLoadContestModule(contentModuleArray);
//            });
//
//            panel.add(选择目标接口模块);
//            panel.add(目标接口模块下拉框);
//
//            panel.add(选择目标场景模块);
//            panel.add(目标场景模块下拉框);


            迁移.addActionListener(new 迁移事件());
            panel.add(迁移);
            panel.add(迁移进度);
            panel.add(提示信息);
        }catch (Exception e) {
            e.printStackTrace();
            提示信息.setText(e.getMessage());
//            wLog(e.getMessage());
        }
    }

    public void loadContestModule(List<ScenarioModuleNode> jsonArray){
        场景模块 = new ConcurrentHashMap<>();
        contextMap = new ConcurrentHashMap<>();
        putScenarioModuleMap(jsonArray, contextMap);
        List<String> names = new ArrayList<>();
        for (Map.Entry<String, ScenarioModuleNode> item : contextMap.entrySet()) {
            String name = getModuleName(item.getValue(), contextMap);
            场景模块.put(name, item.getKey());
            names.add(name);
        }
        names.sort( (o1, o2) -> o1.compareTo(o2));
        names.forEach( item ->{
            源场景模块下拉框.addItem(item);
        });
    }
//    public void goalLoadContestModule(List<ScenarioModuleNode> jsonArray){
//        目标场景模块 = new ConcurrentHashMap<>();
//        goalContextMap = new ConcurrentHashMap<>();
//        putScenarioModuleMap(jsonArray, goalContextMap);
//        for (Map.Entry<String, ScenarioModuleNode> item : goalContextMap.entrySet()) {
//            String name = getModuleName(item.getValue(), goalContextMap);
//            目标场景模块.put(name, item.getKey());
//            目标场景模块下拉框.addItem(name);
//        }
//    }

    public void loadAPIModule(List<ApiModuleNode> apiModules){
        apiMap = new ConcurrentHashMap<>();
        接口模块 = new ConcurrentHashMap<>();
        putModuleMap(apiModules, apiMap);
        List<String> names = new ArrayList<>();
        for (Map.Entry<String, ApiModuleNode> item : apiMap.entrySet()) {
            String name = getName(item.getValue(), apiMap);
            接口模块.put(name, item.getKey());
            names.add(name);
        }
        names.sort( (o1, o2) -> o1.compareTo(o2));
        names.forEach( item ->{
            源接口模块下拉框.addItem(item);
        });
    }
//    public void goalLoadAPIModule(List<ApiModuleNode> apiModules){
//        goalApiMap = new ConcurrentHashMap<>();
//        目标接口模块 = new ConcurrentHashMap<>();
//        putModuleMap(apiModules, goalApiMap);
//        for (Map.Entry<String, ApiModuleNode> item : goalApiMap.entrySet()) {
//            String name = getName(item.getValue(), goalApiMap);
//            目标接口模块.put(name, item.getKey());
//            目标接口模块下拉框.addItem(name);
//        }
//    }
    public String getName(ApiModuleNode value, ConcurrentHashMap<String, ApiModuleNode> map){
        String parentId = value.getParentId();
        String name = value.getName();
        if(parentId != null){
            ApiModuleNode jsonObject = map.get(parentId);
            if(jsonObject != null){
                name = getName(jsonObject, map)+"->"+name;
            }
        }
        return name;
    }

    public String getModuleName(ScenarioModuleNode value, ConcurrentHashMap<String, ScenarioModuleNode> map){
        String parentId = value.getParentId();
        String name = value.getName();
        if(parentId != null){
            ScenarioModuleNode jsonObject = map.get(parentId);
            if(jsonObject != null){
                name = getModuleName(jsonObject, map)+"->"+name;
            }
        }
        return name;
    }

    public void putModuleMap(List<ApiModuleNode> apiModules, ConcurrentHashMap<String, ApiModuleNode> contextMap){
        for(int i = 0 ; i < apiModules.size(); i++){
            ApiModuleNode jsonObject = apiModules.get(i);
            String id = jsonObject.getId();
            contextMap.put(id, jsonObject);
            List<ApiModuleNode> sub = jsonObject.getChildren();
            if(sub != null) {
                putModuleMap(sub, contextMap);
            }
        }
    }

    public void putScenarioModuleMap(List<ScenarioModuleNode>  apiModules, ConcurrentHashMap<String, ScenarioModuleNode> contextMap){
        for(int i = 0 ; i < apiModules.size(); i++){
            ScenarioModuleNode jsonObject = apiModules.get(i);
            String id = jsonObject.getId();
            contextMap.put(id, jsonObject);
            List<ScenarioModuleNode> sub = jsonObject.getChildren();
            if(sub != null) {
                putScenarioModuleMap(sub, contextMap);
            }
        }
    }


    public Set<String> getMSWorkSpace(){

        List<Workspace> workspaces = migrationService.getWorkspaces();
        workspaces.forEach(item ->{
            workspace.put(item.getName(),item.getId());
        });
        return workspace.keySet();
    }

    public Set<String> getGoalMSWorkSpace(){

        List<Workspace> workspaces = goalMigrationService.getWorkspaces();
        workspaces.forEach(item ->{
            goalWorkspace.put(item.getName(),item.getId());
        });
        return goalWorkspace.keySet();
    }



    public List<Project> getMSProject(String workSpaceId){
        List<Project> projects = migrationService.getMSProject(workSpaceId);
        return projects;
    }

    public List<Project> getMSGoalProject(String workSpaceId){
        List<Project> projects = goalMigrationService.getMSProject(workSpaceId);
        return projects;
    }

    public List<ApiModuleNode> getAPIModule(String projectId){
        List<ApiModuleNode> apiModuleNodes = migrationService.getApiModuleNode(projectId);
        return apiModuleNodes;
    }

    public List<ScenarioModuleNode> getContentModule(String projectId){
        List<ScenarioModuleNode> scenarioModuleNodes = migrationService.getApiScenarioModuleNode(projectId);
        return scenarioModuleNodes;
    }

    public void getEnvironmentModule(String projectId){
        Set<String> environments = getEnvironments(projectId);
        List<String> environmentModule = new ArrayList<>(environments);
        Collections.sort(environmentModule, (o1, o2) -> o1.compareTo(o2));
        Iterator<String> env = environmentModule.iterator();
        while (env.hasNext()){
            环境下拉框.addItem(new JCheckBox(env.next()));
        }
    }


    private void getImportType (JComboBox comboBox,ConcurrentHashMap<String, String> map){
        String importType = (String) comboBox.getSelectedItem();
        if(StringUtils.equals(map.get(importType), AdminConstants.FULL_COVERAGE)){
            IMPORT_TYPE = true;
        }
    }

    private String getProjectId(JComboBox comboBox,ConcurrentHashMap<String, String> map){
        String itemString = (String) comboBox.getSelectedItem();
        String projectId = map.get(itemString);
        return projectId;
    }

    private String getApiModuleNode(JComboBox comboBox,ConcurrentHashMap<String, String> map){
        String moduleName = (String) comboBox.getSelectedItem();
        return map.get(moduleName);
    }

    private String getScenarioModuleNode(JComboBox comboBox,ConcurrentHashMap<String, String> map){
        String moduleName = (String) comboBox.getSelectedItem();
        return map.get(moduleName);
    }

    private List<String> getEnvironmentIds(JComboBox<JCheckBox> comboBox ,ConcurrentHashMap<String, String> map){
        List<String> envIds = new ArrayList<>();
        if(IMPORT_TYPE){
            envIds.addAll(environment.values());
        }
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            JCheckBox checkbox = comboBox.getItemAt(i);
            if (checkbox.isSelected()) {
                envIds.add(map.get(checkbox.getText()));
            }
        }
        return envIds;
    }

    class 迁移事件 implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent arg0)
        {
            迁移.setEnabled(false);
            try {
                convert();
            }catch (Exception e){
                提示信息.setText(e.getMessage());
                e.printStackTrace();
            }finally {
                迁移.setEnabled(true);
                容器.validate();
                容器.repaint();
            }
        }
    }



    private void 修改迁移进度(int i){
        迁移进度.setText("迁移进度  "+i+"%");
        容器.validate();
        容器.repaint();
    }
    private void convert(){
        修改迁移进度(1);
        getImportType(导入模式下拉框,importTypeMap);
        String projectId = getProjectId(源项目下拉框,projectMap);
        String apiModuleId = getApiModuleNode(源接口模块下拉框,接口模块);
        String scenarioModuleNode = getScenarioModuleNode(源场景模块下拉框,场景模块);
        List<String> envList = getEnvironmentIds(环境下拉框,environment);
        String goalProjectId = getProjectId(目标项目下拉框,goalProjectMap);
        //String goalApiModuleId = getApiModuleNode(目标接口模块下拉框,目标接口模块);
        //String goalScenarioModuleNode = getScenarioModuleNode(目标场景模块下拉框,目标场景模块);
        修改迁移进度(10);



        //处理API定义路径、API定义、API_CASE、环境（模块）
        convertEnvService.initOrderAndNum(goalProjectId);
        convertEnvService.compareCreateApiModulePath(projectId,goalProjectId);
        convertEnvService.convertEnv(envList,projectId,goalProjectId);
        convertEnvService.convertVersion(projectId,goalProjectId);
        convertEnvService.convertApiAndCaseByModuleId(apiModuleId,projectId,goalProjectId);

        修改迁移进度(65);
        //处理场景模块路径、场景
        convertEnvService.convertScenarioModulePath(projectId,goalProjectId);
        convertEnvService.convertApiScenarioByModuleId(scenarioModuleNode,projectId,goalProjectId);
        修改迁移进度(84);
        convertEnvService.convertScenarioReference(goalProjectId);



        修改迁移进度(99);

        convertEnvService.clearStaticData();
        try{
            //String apiData = conver.apiConver(API文件信息, toProjectID, toAPIModuleID, 获取导入请求参数(toProjectID, toAPIModuleID), getUrl());

           // conver.contextConver(场景文件信息, apiData, 获取导入请求参数(toProjectID, toCentextModuleId), toProjectID, toCentextModuleId, getUrl());
            修改迁移进度(100);
            System.out.println( 源项目下拉框.getSelectedItem() + "------迁移完毕!");
        }catch (Exception e){
            e.printStackTrace();
            提示信息.setText(e.getMessage());
//            wLog(e.getMessage());
        }
    }


//    public String apiConver(String APIData, String toProjectID, String toModuleID, String requestFileStr, String apiFilePath) {
//        if (apiFilePath == null)
//            apiFilePath = "/opt/metersphere/data/file/" + toProjectID + "/" + toModuleID;
//        APIFileEntity apiEntity = (APIFileEntity)JSON.parseObject(APIData, APIFileEntity.class);
//        String fileName = "MeterSphereAPI.json";
//        UseFile.writeTxt(apiFilePath, fileName, JSON.toJSONString(apiEntity));
//        String response = null;
//        try {
//            response = client.importAPI(apiFilePath, fileName, requestFileStr);
//        } catch (Exception exception) {}
//        List<CaseEntity> caseEntityList = apiEntity.getCases();
//        List<ApiEntity> apiEntityList = apiEntity.getData();
//        Map<String, CaseEntity> caseMap = new HashMap<>();
//        Map<String, ApiEntity> apiMap = new HashMap<>();
//        caseEntityList.forEach(item -> {
//            ApiEntity api = (ApiEntity)JSONObject.parseObject(item.getRequest(), ApiEntity.class);
//            caseMap.put(api.getPath(), item);
//        });
//        apiEntityList.forEach(item -> apiMap.put(item.getPath(), item));
//        ResultEntity resultEntity = (ResultEntity)JSONObject.parseObject(response, ResultEntity.class);
//        APIFileEntity newApiEntity = (APIFileEntity)JSON.parseObject(JSONObject.toJSONString(resultEntity.getData(), new com.alibaba.fastjson2.JSONWriter.Feature[0]), APIFileEntity.class);
//        if (newApiEntity.getData() != null && newApiEntity.getData().size() != 0)
//            for (ApiEntity item : newApiEntity.getData()) {
//                ApiEntity temp = apiMap.get(item.getPath());
//                if (temp != null)
//                    item.setOldID(temp.getId());
//            }
//        if (newApiEntity.getCases() != null && newApiEntity.getCases().size() != 0)
//            for (CaseEntity item : newApiEntity.getCases()) {
//                ApiEntity temp = (ApiEntity)JSONObject.parseObject(item.getRequest(), ApiEntity.class);
//                CaseEntity caseTemp = caseMap.get(temp.getPath());
//                if (caseTemp != null)
//                    item.setOldID(caseTemp.getId());
//            }
//        return JSONObject.toJSONString(newApiEntity, new com.alibaba.fastjson2.JSONWriter.Feature[0]);
//    }
    public Set<String> getEnvironments(String projectId){
        environment.clear();
        List<ApiTestEnvironment> environments = migrationService.getEnvironments(projectId);
        environments.forEach(item ->{
            environment.put(item.getName(),item.getId());
        });
        return environment.keySet();
    }

    public void initUI() {
        // 创建并显示 Swing 界面

            容器 = new JFrame("MeterSphere 项目迁移");
            容器.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            面板 = new JPanel();
            面板.setLayout(null);
            //检测配置文件
            获取面板(面板);
            容器.add(面板);
            容器.setSize(600,500);
            容器.setVisible(true);

    }



}