package com.ms.migration.tools;

/**
 * @Classname ServiceUtils
 * @Description TODO
 * @Date 2023/8/29 下午4:55
 * @Created by liujianqiang
 */

import org.springframework.beans.BeanUtils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.function.*;

/**
 * @author liujianqiang
 */
public class ServiceUtils {

    public static final int ORDER_STEP = 5000;

    public static void copyProperties(Object source, Object target) {
        Class<?> clazzT= target.getClass();

        Long createTime = System.currentTimeMillis();
        Long updateTime = System.currentTimeMillis();

        try {
            Method setCreateTime = clazzT.getMethod("setCreateTime", Long.class);
            Method setUpdateTime = clazzT.getMethod("setUpdateTime", Long.class);

            BeanUtils.copyProperties(source,target);
            setCreateTime.invoke(target,createTime);
            setUpdateTime.invoke(target,updateTime);

        } catch (Throwable e) {

        }
    }

    /**
     * 创建时获取下一个 order 值
     *
     * @param groupId
     * @param getLastOrderFunc
     * @return
     */
    public static Long getNextOrder(String groupId, BiFunction<String, Long, Long> getLastOrderFunc) {
        Long lastOrder = getLastOrderFunc.apply(groupId, null);
        return (lastOrder == null ? 0 : lastOrder) + ServiceUtils.ORDER_STEP;
    }

    public static <T> int getNextNum(String projectId, Class<T> clazz, Function<String, T> getNextNumFunc) {
        T data = getNextNumFunc.apply(projectId);
        try {
            Method getNum = clazz.getMethod("getNum");
            if (data == null || getNum.invoke(data) == null) {
                return 100001;
            } else {
                return Optional.ofNullable((Integer) getNum.invoke(data) + 1).orElse(100001);
            }
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        return 100001;
    }


    public static String getCopyName(String name) {
        return "copy_" + name + "_" + UUID.randomUUID().toString().substring(0, 4);
    }


    public static Boolean checkConfigEnable(Map config, String key, String subKey) {
        if (config == null || config.get(key) == null) {
            return true;
        } else {
            Map configItem = (Map) config.get(key);
            Boolean enable = (Boolean) configItem.get("enable");
            if (enable) {
                Map subConfig = (Map) ((Map) configItem.get("children")).get(subKey);
                if (subConfig == null) {
                    return true;
                }
                return (Boolean) subConfig.get("enable");
            } else {
                return false;
            }
        }
    }

    public static Boolean checkConfigEnable(Map config, String key) {
        if (config == null) {
            return true;
        } else {
            Map configItem = (Map) config.get(key);
            if (configItem == null) {
                return true;
            }
            return (Boolean) configItem.get("enable");
        }
    }





}
