package com.ms.migration.tools;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
/**
 * @Classname UseFile
 * @Description TODO
 * @Date 2023/11/6 下午2:42
 * @Created by liujianqiang
 */
public class UseFile {
    public static void writeTxt(String fileName, String content) {
        try {
            File file = new File(fileName);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fileWriter = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fileWriter);
            bw.write(content);
            bw.close();
            System.out.println("finish");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public byte[] InputStream2ByteArray(String filePath) throws IOException {
        InputStream in = new FileInputStream(filePath);
        byte[] data = toByteArray(in);
        in.close();
        return data;
    }

    private byte[] toByteArray(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int n = 0;
        while ((n = in.read(buffer)) != -1) {
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }

    public static String readTxt(String filePath) {
        String str = "";
        try {
            File file = new File(filePath);
            System.out.println("+ file.length() / 1024L + KB");
            if (file.isFile() && file.exists()) {
                InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "utf-8");
                BufferedReader br = new BufferedReader(isr);
                int num = 0;
                String context = null;
                while ((context = br.readLine()) != null) {
                    str = str + context;
                    num++;
                }
                System.out.println("readTxt" + str.length());
                br.close();
            } else {
                System.out.println("");
            }
        } catch (Exception e) {
            System.out.println("");
        }
        return str;
    }

    public static File readFile(String filePath) {
        File file = new File(filePath);
        return file;
    }

    public static String getContextByFile(File file) {
        String str = "";
        try {
            System.out.println("+ file.length() / 1024L + KB");
            if (file.isFile() && file.exists()) {
                InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "utf-8");
                BufferedReader br = new BufferedReader(isr);
                int num = 0;
                String context = null;
                while ((context = br.readLine()) != null) {
                    str = str + context;
                    num++;
                }
                System.out.println("getContextByFile"+ str.length());
                        br.close();
            } else {
                System.out.println("");
            }
        } catch (Exception e) {
            System.out.println("");
        }
        return str;
    }

    public static void writeTxt(String path, String fileName, String content) {
        try {
            File file = new File(path);
            file.mkdirs();
            file = new File(path + "/" + path);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fileWriter = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fileWriter);
            bw.write(content);
            bw.close();
            System.out.println("finish");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

