/**
 * @Classname xxx
 * @Description TODO
 * @Date 2023/11/13 下午2:18
 * @Created by liujianqiang
 */
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;



public class xxx {
    public static void main(String[] args) {
        System.out.println("start");
        String secret = "a46de5b8e73f4c2fb00be7e9aeaf58503b6fc248558c4f06b8801929335b609f";
        String clientId = "9d21c8646fac4f0c858cd0ebf1283b83";
        long timestamp = System.currentTimeMillis();
        String combinedString = secret + clientId + Long.toString(timestamp) + secret;
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            byte[] digest = messageDigest.digest(combinedString.getBytes("UTF-8"));
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < digest.length; i++) {
                byte b = digest[i];
                stringBuilder.append(String.format("%02x", b));
            }
//            vars.put("sign",stringBuilder.toString());
//            log.info("1111");
            System.out.println(stringBuilder.toString());
            // return stringBuilder.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            // return "";
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            // return "";

        }
    }
}
